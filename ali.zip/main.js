const { app, BrowserWindow, ipcMain, session, Menu } = require('electron');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const ExcelJS = require('exceljs');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
let win;
let db;

const jalaali = require('jalaali-js');

function getJalaliMonthDays() {
  const now = new Date();
  const { jy, jm } = jalaali.toJalaali(now);

  // استفاده از isValidJalaaliDate برای پیدا کردن تعداد روزهای ماه
  const daysInMonth = jalaali.jalaaliMonthLength(jy, jm);
  return daysInMonth;
}

function createWindow() {
  const isDev = process.env.NODE_ENV === 'development';

  win = new BrowserWindow({
    width: 800,
    height: 600,
    frame: false, // مخفی کردن نوار ابزار ویندوز
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#1e1e1e',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: true,
    },
  });

  win.maximize();
  Menu.setApplicationMenu(null);

  // Set Content Security Policy
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': [
          "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:;"
        ],
      },
    });
  });

  if (isDev) {
    // اتصال به React Dev Server
    win.loadURL('http://localhost:3010'); // مطمئن شو پورت Dev Server همینه
    win.webContents.openDevTools({ mode: 'detach' });

    // Hot Reload برای Main process
    try {
      require('electron-reloader')(module, {
        watchRenderer: true,
        watchIgnore: [/shahbaz\.db$/, /node_modules/, /build/],
      });
    } catch (err) {
      console.log('🔄 Electron reloader failed:', err);
    }
  } else {
    // حالت Production
    win.loadFile(path.join(__dirname, 'build', 'index.html'));
  }

  // رویداد بستن پنجره
  win.on('closed', () => {
    win = null;
  });
}
function initDb() {
  db = new sqlite3.Database('d:/shahbaz.db', (err) => {
    if (err) {
      console.error('خطا در اتصال به دیتابیس:', err.message);
      return;
    }
    db.run(`
      CREATE TABLE IF NOT EXISTS order_viewers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
)

      `);

    db.run(`
CREATE TABLE IF NOT EXISTS order_viewer_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  viewer_id INTEGER NOT NULL,
  product_name TEXT NOT NULL,
  FOREIGN KEY (viewer_id) REFERENCES order_viewers(id) ON DELETE CASCADE
)
        `);

    db.run(`CREATE TABLE IF NOT EXISTS tables (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      user_name TEXT,
      user_phone TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS tables_orders (
      _order INTEGER,
      _parent_id INTEGER,
      id TEXT PRIMARY KEY,
      product TEXT,
      quantity INTEGER,
      price REAL,
      FOREIGN KEY(_parent_id) REFERENCES tables(id) ON DELETE CASCADE
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS game_orders (
      id TEXT PRIMARY KEY,
      table_id INTEGER,
      type TEXT,
      controllers_or_players INTEGER,
      minutes INTEGER,
      start_time TEXT,
      end_time TEXT,
      FOREIGN KEY(table_id) REFERENCES tables(id) ON DELETE CASCADE
    )`);
  });
}


app.whenReady().then(() => {
  initDb();
  createWindow();
});

app.on('window-all-closed', () => {
  if (db) db.close();
  if (process.platform !== 'darwin') app.quit();
});

// IPC handlers
ipcMain.handle('create-table', (event, data) => {
  return new Promise((resolve, reject) => {
    const sql = `
      INSERT INTO tables (name, user_name, user_phone)
      VALUES (?, ?, ?)`;
    db.run(sql, [data.name, data.user_name, data.user_phone], function (err) {
      if (err) {
        reject(err);
      } else {
        resolve({ id: this.lastID });
      }
    });
  });
});

ipcMain.handle('get-tables', (event) => {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM tables', (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
});
ipcMain.handle('update-table', (event, table) => {
  return new Promise((resolve, reject) => {
    const sql = `
      UPDATE tables
      SET name = ?, user_name = ?, user_phone = ?
      WHERE id = ?
    `;
    db.run(sql, [table.name, table.user_name, table.user_phone, table.id], function (err) {
      if (err) {
        reject(err);
      } else {
        resolve({ success: true, id: table.id, changes: this.changes });
      }
    });
  });
});

ipcMain.handle('delete-table', (event, id) => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run('BEGIN TRANSACTION');

      db.run('DELETE FROM tables_orders WHERE _parent_id = ?', [id], (err) => {
        if (err) {
          db.run('ROLLBACK');
          return reject(err);
        }

        db.run('DELETE FROM game_orders WHERE table_id = ?', [id], (err) => {
          if (err) {
            db.run('ROLLBACK');
            return reject(err);
          }

          db.run('DELETE FROM tables WHERE id = ?', [id], function (err) {
            if (err) {
              db.run('ROLLBACK');
              return reject(err);
            }
            db.run('COMMIT');
            resolve({ deleted: this.changes > 0 });
          });
        });
      });
    });
  });
});



// دریافت دسته‌بندی‌های منو
ipcMain.handle('get-menu-categories', () => {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM menu_categories ORDER BY name', (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
});

// دریافت آیتم‌های منو براساس دسته‌بندی
ipcMain.handle('get-menu-items-by-category', (event, categoryId) => {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT id, title, description, price, image_id, category_id
      FROM menuitems
      WHERE category_id = ?
      ORDER BY title
    `;
    db.all(sql, [categoryId], (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
});

ipcMain.handle('save-order', async (event, { tableId, items }) => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run("BEGIN TRANSACTION");

      // پاک کردن سفارشات قبلی میز
      db.run("DELETE FROM tables_orders WHERE _parent_id = ?", [tableId], (err) => {
        if (err) {
          db.run("ROLLBACK");
          return reject(err);
        }

        const insert = db.prepare(`
          INSERT INTO tables_orders (_order, _parent_id, id, product, quantity, price)
          VALUES (?, ?, ?, ?, ?, ?)
        `);

        for (let index = 0; index < items.length; index++) {
          const item = items[index];
          insert.run(
            index + 1,
            tableId,
            uuidv4(),
            item.title,
            item.quantity,
            item.price
          );
        }

        insert.finalize((err) => {
          if (err) {
            db.run("ROLLBACK");
            return reject(err);
          }
          db.run("COMMIT");
          resolve({ success: true });
        });
      });
    });
  });
});


ipcMain.handle('get-orders-by-table', (event, tableId) => {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT id, product, quantity, price, (quantity * price) AS total
      FROM tables_orders
      WHERE _parent_id = ?
      ORDER BY _order ASC
    `;
    db.all(sql, [tableId], (err, rows) => {
      if (err) {
        console.error('❌ خطا در دریافت سفارشات:', err);
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
});

ipcMain.handle('save-game-order', async (event, { tableId, type, controllers_or_players, minutes, startTime, endTime }) => {
  return new Promise((resolve, reject) => {
    const id = uuidv4();

    const sql = `
      INSERT INTO game_orders (id, table_id, type, controllers_or_players, minutes, start_time, end_time)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        controllers_or_players=excluded.controllers_or_players,
        minutes=excluded.minutes,
        start_time=excluded.start_time,
        end_time=excluded.end_time
    `;

    db.run(sql, [
      id,
      tableId,
      type,
      controllers_or_players,
      minutes,
      startTime,
      endTime
    ], function (err) {
      if (err) reject(err);
      else resolve({ success: true, id });
    });
  });
});



ipcMain.handle('get-game-orders-by-table', (event, tableId) => {
  return new Promise((resolve, reject) => {
    db.all(`SELECT * FROM game_orders WHERE table_id = ?`, [tableId], (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
});

ipcMain.handle('delete-game-order', (event, order) => {
  return new Promise((resolve, reject) => {
    const deleteSql = `DELETE FROM game_orders WHERE table_id = ? AND type = ?`;
    db.run(deleteSql, [order.tableId, order.type], function (err) {
      if (err) {
        return reject(err);
      }
      resolve({
        success: true,
        deletedCount: this.changes, // تعداد ردیف‌هایی که حذف شدند
      });
    });
  });
});

/**
 * تابعی برای محاسبه خلاصه سفارشات در بازه تاریخی
 * ورودی: startDate و endDate (فرمت 'YYYY-MM-DD')
 * خروجی: { items: [{ item, quantity, total }], totalAmount }
 */
ipcMain.handle('get-orders-summary', async (event, { startDate, endDate }) => {
  return new Promise((resolve, reject) => {

    /* 1️⃣ دریافت فاکتورها */
    const factorSql = `
      SELECT id, total, offer, paid, name, created_at
      FROM factororder
      WHERE created_at BETWEEN ? AND ?
      ORDER BY created_at ASC
    `;

    db.all(factorSql, [startDate, endDate], (err, factors) => {
      if (err) {
        return reject({ success: false, error: err.message });
      }

      if (!factors.length) {
        return resolve({
          success: true,
          factors: [],
          orders: [],
          summary: [],
          totalAmount: 0
        });
      }

      const factorIds = factors.map(f => f.id);

      /* 2️⃣ دریافت سفارشات این فاکتورها */
      const ordersSql = `
        SELECT 
          o._parent_id AS factorId,
          o.product,
          o.quantity,
          o.price,
          f.offer
        FROM factororder_orders o
        JOIN factororder f ON o._parent_id = f.id
        WHERE o._parent_id IN (${factorIds.map(() => '?').join(',')})
      `;

      db.all(ordersSql, factorIds, (err, orders) => {
        if (err) {
          return reject({ success: false, error: err.message });
        }

        let totalAmount = 0;
        const summaryMap = {};

        const processedOrders = orders.map(o => {
          let lineTotal = o.quantity * o.price;

          /* تخفیف فاکتور */
          if (o.offer > 0) {
            lineTotal = lineTotal * (1 - o.offer / 100);
          }

          /* پلی‌استیشن / بردگیم */
          const productName = (o.product || '').toLowerCase();
          const isPlayStation =
            productName.includes('پلی') || productName.includes('playstation');
          const isBoardGame =
            productName.includes('برد') || productName.includes('board');

          if (isPlayStation || isBoardGame) {
            lineTotal = Math.floor(lineTotal / 60);
          } else {
            lineTotal = Math.floor(lineTotal);
          }

          totalAmount += lineTotal;

          /* ساخت summary */
          if (!summaryMap[o.product]) {
            summaryMap[o.product] = {
              item: o.product,
              quantity: 0,
              total: 0
            };
          }

          summaryMap[o.product].quantity += o.quantity;
          summaryMap[o.product].total += lineTotal;

          return {
            factorId: o.factorId,
            product: o.product,
            quantity: o.quantity,
            unitPrice: o.price,
            total: lineTotal
          };
        });

        const summary = Object.values(summaryMap).sort(
          (a, b) => b.total - a.total
        );

        resolve({
          success: true,
          factors,
          orders: processedOrders,
          summary,
          totalAmount
        });
      });
    });
  });
});




ipcMain.handle('get-order-viewers', async () => {
  try {
    const viewers = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM order_viewers ORDER BY name', [], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });

    // گرفتن آیتم‌های هر Viewer
    const viewersWithItems = await Promise.all(viewers.map(async (v) => {
      const items = await new Promise((resolve, reject) => {
        db.all('SELECT * FROM order_viewer_items WHERE viewer_id = ? ORDER BY id', [v.id], (err, rows) => {
          if (err) return reject(err);
          resolve(rows.map(r => r.product_name));
        });
      });
      return {
        id: v.id,
        name: v.name,
        items
      };
    }));

    return { success: true, viewers: viewersWithItems };
  } catch (err) {
    console.error('Error fetching order viewers:', err);
    return { success: false, error: err.message };
  }
});
ipcMain.handle('create-order-viewer', async (event, payload) => {
  const { name, items } = payload;
  if (!name || !items || !Array.isArray(items)) {
    return { success: false, error: 'نام و آرایه آیتم‌ها لازم است' };
  }

  try {
    const viewerId = await new Promise((resolve, reject) => {
      db.run('INSERT INTO order_viewers (name) VALUES (?)', [name], function (err) {
        if (err) return reject(err);
        resolve(this.lastID); // id اتوماتیک
      });
    });

    // اضافه کردن آیتم‌ها
    const insertItems = items.map(item => {
      return new Promise((res, rej) => {
        db.run('INSERT INTO order_viewer_items (viewer_id, product_name) VALUES (?, ?)', [viewerId, item], (err) => {
          if (err) return rej(err);
          res();
        });
      });
    });
    await Promise.all(insertItems);

    return { success: true, id: viewerId };
  } catch (err) {
    console.error('Error creating order viewer:', err);
    return { success: false, error: err.message };
  }
});
// Handler برای بروزرسانی Viewer
ipcMain.handle('update-order-viewer', async (event, payload) => {
  const { id, name, items } = payload;

  if (!id || !name || !items || !Array.isArray(items)) {
    return { success: false, error: 'شناسه، نام و آرایه آیتم‌ها لازم است' };
  }

  try {
    // بروزرسانی نام
    await new Promise((resolve, reject) => {
      db.run('UPDATE order_viewers SET name = ? WHERE id = ?', [name, id], function (err) {
        if (err) return reject(err);
        resolve();
      });
    });

    // حذف تمام آیتم‌های قبلی
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM order_viewer_items WHERE viewer_id = ?', [id], function (err) {
        if (err) return reject(err);
        resolve();
      });
    });

    // اضافه کردن آیتم‌های جدید
    const insertItems = items.map(item => {
      return new Promise((res, rej) => {
        db.run(
          'INSERT INTO order_viewer_items (viewer_id, product_name) VALUES (?, ?)',
          [id, item],
          (err) => {
            if (err) return rej(err);
            res();
          }
        );
      });
    });

    await Promise.all(insertItems);

    return { success: true };
  } catch (err) {
    console.error('Error updating order viewer:', err);
    return { success: false, error: err.message };
  }
});

// Handler جدا برای حذف Viewer
ipcMain.handle('delete-order-viewer', async (event, id) => {
  if (!id) return { success: false, error: 'شناسه لازم است' };

  try {
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM order_viewers WHERE id = ?', [id], function (err) {
        if (err) return reject(err);
        resolve();
      });
    });

    // با ON DELETE CASCADE، آیتم‌ها هم حذف می‌شوند
    return { success: true };
  } catch (err) {
    console.error('Error deleting order viewer:', err);
    return { success: false, error: err.message };
  }
});


//////////////////////////////////////
ipcMain.handle('get-material-categories', () => {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM material_cat ORDER BY name', (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
});

ipcMain.handle('create-material-category', (event, name) => {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO material_cat (name) VALUES (?)`;
    db.run(sql, [name], function (err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, name });
    });
  });
});

ipcMain.handle('update-material-category', (event, category) => {
  return new Promise((resolve, reject) => {
    const sql = `UPDATE material_cat SET name = ? WHERE id = ?`;
    db.run(sql, [category.name, category.id], function (err) {
      if (err) reject(err);
      else resolve({ success: true, changes: this.changes });
    });
  });
});



ipcMain.handle(
  'prepare-delete-material-category',
  async (event, categoryId) => {
    try {
      // مواد این دسته
      const materials = await all(
        `SELECT id, name FROM materials WHERE category_id = ?`,
        [categoryId]
      );

      const materialIds = materials.map(m => m.id);

      if (!materialIds.length) {
        return { success: true, empty: true, materials: [] };
      }

      // استفاده در مواد ترکیبی
      const usedInComposites = await all(`
        SELECT 
          mc.material_id,
          m.name AS compositeName
        FROM materials_components mc
        JOIN materials m ON mc._parent_id = m.id
        WHERE mc.material_id IN (${materialIds.map(() => '?').join(',')})
      `, materialIds);

      // استفاده در رسپی کارت‌ها
      const usedInRecipes = await all(`
        SELECT 
          ri.material_id,
          mi.title AS menuTitle
        FROM recepcard_ingredients ri
        JOIN recepcard rc ON ri._parent_id = rc.id
        JOIN menuitems mi ON rc.menu_item_id = mi.id
        WHERE ri.material_id IN (${materialIds.map(() => '?').join(',')})
      `, materialIds);

      return {
        success: true,
        materials,
        usedInComposites,
        usedInRecipes,
      };
    } catch (err) {
      console.error(err);
      return { success: false, error: err.message };
    }
  }
);
ipcMain.handle(
  'confirm-delete-material-category',
  async (event, categoryId) => {
    try {
      await run('BEGIN TRANSACTION');

      const materials = await all(
        `SELECT id FROM materials WHERE category_id = ?`,
        [categoryId]
      );

      for (const mat of materials) {
        const id = mat.id;

        // حذف از ترکیبات دیگر
        await run(
          `DELETE FROM materials_components WHERE material_id = ?`,
          [id]
        );

        // حذف از رسپی کارت‌ها
        await run(
          `DELETE FROM recepcard_ingredients WHERE material_id = ?`,
          [id]
        );

        // اگر خودش ترکیبی است → ترکیباتش
        await run(
          `DELETE FROM materials_components WHERE _parent_id = ?`,
          [id]
        );

        // حذف خود ماده
        await run(
          `DELETE FROM materials WHERE id = ?`,
          [id]
        );
      }

      // حذف دسته‌بندی
      await run(
        `DELETE FROM material_cat WHERE id = ?`,
        [categoryId]
      );

      await run('COMMIT');

      return { success: true };
    } catch (err) {
      await run('ROLLBACK');
      console.error(err);
      return { success: false, error: err.message };
    }
  }
);

const { logObj, logInfo, logError } = require('./logger');



ipcMain.handle('get-materials', () => {

  return new Promise((resolve, reject) => {

    const sql = `
      SELECT 
        m.id, 
        m.name, 
        m.stock, 
        m.unit_price AS unitPrice, 
        m.measure_type AS measureType, 
        m.unit, 
        m.is_composite AS isComposite,
        m.unit_yield AS unitYield,
        c.id as categoryId, 
        c.name as categoryName
      FROM materials m
      LEFT JOIN material_cat c ON m.category_id = c.id
      ORDER BY m.name
    `;

    db.all(sql, [], (err, materials) => {
      if (err) return reject(err);

      // برای هر ماده ترکیبی، ترکیباتش را هم اضافه می‌کنیم
      const promises = materials.map(mat => {
        if (!mat.isComposite) return Promise.resolve({ ...mat, components: [] });

        return new Promise((res, rej) => {
          const compSQL = `
            SELECT 
              mc.id,
              mc.quantity,
              mc._order,
              m2.id as materialId,
              m2.name as materialName,
              m2.unit_price AS unitPrice,
              m2.unit
            FROM materials_components mc
            LEFT JOIN materials m2 ON mc.material_id = m2.id
            WHERE mc._parent_id = ?
            ORDER BY mc._order
          `;
          db.all(compSQL, [mat.id], (err, comps) => {
            if (err) return rej(err);
            res({ ...mat, components: comps });
          });
        });
      });

      Promise.all(promises)
        .then(results => resolve(results))
        .catch(reject);
    });
  });
});

// ایجاد ماده اولیه

ipcMain.handle('create-material', async (event, material) => {
  return new Promise((resolve, reject) => {
    const {
      name,
      categoryId,
      measureType,
      unit,
      stock,
      unitPrice,
      isComposite = false,
      unitYield = 1,
      components = [],
    } = material;

    const sql = `
      INSERT INTO materials
        (name, category_id, measure_type, unit, stock, unit_price, is_composite, unit_yield)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.run(
      sql,
      [name, categoryId, measureType, unit, stock, unitPrice, isComposite ? 1 : 0, unitYield],
      function (err) {
        if (err) return reject(err);

        const materialId = this.lastID;

        if (!isComposite || !components.length) return resolve({ id: materialId, ...material });

        // ذخیره ترکیبات
        const insertCompSQL = `
          INSERT INTO materials_components (_order, _parent_id, id, material_id, quantity)
          VALUES (?, ?, ?, ?, ?)
        `;
        components.forEach((comp, index) => {
          db.run(
            insertCompSQL,
            [index + 1, materialId, uuidv4(), comp.materialId, comp.quantity],
            (err) => {
              if (err) console.error('Error inserting component:', err);
            }
          );
        });

        resolve({ id: materialId, ...material });
      }
    );
  });
});


// ویرایش ماده اولیه
ipcMain.handle('update-material', async (event, material) => {
  return new Promise((resolve, reject) => {
    const {
      id,
      name,
      categoryId,
      measureType,
      unit,
      stock,
      unitPrice,
      isComposite = false,
      unitYield = 1,
      components = [],
    } = material;

    const sql = `
      UPDATE materials
      SET name = ?, category_id = ?, measure_type = ?, unit = ?, stock = ?, unit_price = ?, is_composite = ?, unit_yield = ?
      WHERE id = ?
    `;

    db.run(
      sql,
      [name, categoryId, measureType, unit, stock, unitPrice, isComposite ? 1 : 0, unitYield, id],
      function (err) {
        if (err) return reject(err);

        if (!isComposite) {
          // اگر ماده ساده است، ترکیبات قبلی حذف شود
          db.run('DELETE FROM materials_components WHERE _parent_id = ?', [id], (err) => {
            if (err) console.error('Error deleting old components:', err);
          });
          return resolve({ success: true, changes: this.changes });
        }

        // اگر ماده ترکیبی است، ترکیبات قدیمی حذف و ترکیبات جدید اضافه شود
        db.run('DELETE FROM materials_components WHERE _parent_id = ?', [id], (err) => {
          if (err) return reject(err);

          const insertCompSQL = `
            INSERT INTO materials_components (_order, _parent_id, id, material_id, quantity)
            VALUES (?, ?, ?, ?, ?)
          `;
          components.forEach((comp, index) => {
            db.run(
              insertCompSQL,
              [index + 1, id, uuidv4(), comp.materialId, comp.quantity],
              (err) => {
                if (err) console.error('Error inserting component:', err);
              }
            );
          });

          resolve({ success: true, changes: this.changes });
        });
      }
    );
  });
});


// حذف ماده اولیه
function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve({ changes: this.changes });
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}


ipcMain.handle('check-material-usage', async (event, materialId) => {
  try {
    // 1️⃣ استفاده در مواد ترکیبی
    const usedInComposites = await all(`
      SELECT m.id, m.name
      FROM materials_components mc
      JOIN materials m ON mc._parent_id = m.id
      WHERE mc.material_id = ?
    `, [materialId]);

    // 2️⃣ استفاده در رسپی کارت‌ها
    const usedInRecipes = await all(`
      SELECT 
        rc.id AS recepCardId,
        mi.title AS menuTitle
      FROM recepcard_ingredients ri
      JOIN recepcard rc ON ri._parent_id = rc.id
      JOIN menuitems mi ON rc.menu_item_id = mi.id
      WHERE ri.material_id = ?
    `, [materialId]);

    return {
      success: true,
      usedInComposites,
      usedInRecipes,
    };
  } catch (err) {
    console.error('check-material-usage error:', err);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('delete-material-force', async (event, materialId) => {
  try {
    await run('BEGIN TRANSACTION');

    // 🔹 حذف از مواد ترکیبی دیگر
    await run(
      'DELETE FROM materials_components WHERE material_id = ?',
      [materialId]
    );

    // 🔹 حذف از رسپی کارت‌ها
    await run(
      'DELETE FROM recepcard_ingredients WHERE material_id = ?',
      [materialId]
    );

    // 🔹 اگر خودش ماده ترکیبی است → ترکیباتش حذف شوند
    await run(
      'DELETE FROM materials_components WHERE _parent_id = ?',
      [materialId]
    );

    // 🔹 حذف خود ماده
    const result = await run(
      'DELETE FROM materials WHERE id = ?',
      [materialId]
    );

    await run('COMMIT');

    return {
      success: true,
      deleted: result.changes,
    };
  } catch (err) {
    await run('ROLLBACK');
    console.error('delete-material-force error:', err);
    return { success: false, error: err.message };
  }
});





ipcMain.handle('delete-material-component', (event, { parentId, materialId }) => {
  return new Promise((resolve, reject) => {
    db.run(
      `DELETE FROM materials_components WHERE _parent_id = ? AND material_id = ?`,
      [parentId, materialId],
      function (err) {
        if (err) return reject(err);
        resolve({ success: true, deleted: this.changes });
      }
    );
  });
});




ipcMain.handle('get-recipe-cards-by-menu-items', async (event, menuItemIds) => {
  try {
    if (!Array.isArray(menuItemIds) || menuItemIds.length === 0) return []

    // 1. fetch recepcards
    const cards = await new Promise((resolve, reject) => {
      const placeholders = menuItemIds.map(() => '?').join(',')
      db.all(
        `SELECT id, menu_item_id FROM recepcard WHERE menu_item_id IN (${placeholders})`,
        menuItemIds,
        (err, rows) => (err ? reject(err) : resolve(rows))
      )
    })

    if (!cards.length) return []

    const cardIds = cards.map(c => c.id)

    // 2. fetch ingredients
    const placeholders = cardIds.map(() => '?').join(',')
    const ingredients = await new Promise((resolve, reject) => {
      db.all(
        `SELECT ri._order, ri._parent_id, ri.id, ri.material_id, ri.quantity, 
                m.name, m.unit, m.unit_price
         FROM recepcard_ingredients ri
         LEFT JOIN materials m ON m.id = ri.material_id
         WHERE ri._parent_id IN (${placeholders})
         ORDER BY ri._parent_id, ri._order`,
        cardIds,
        (err, rows) => (err ? reject(err) : resolve(rows))
      )
    })

    // 3. group ingredients by parent_id
    const map = {}
    cards.forEach(c => {
      map[c.menu_item_id] = {
        id: c.id,
        menu_item_id: c.menu_item_id,
        ingredients: [],
      }
    })

    ingredients.forEach(i => {
      const card = cards.find(c => c.id === i._parent_id)
      if (card) {
        map[card.menu_item_id].ingredients.push({
          materialId: i.material_id,
          quantity: i.quantity,
          name: i.name || '',
          unit: i.unit || '',
          unitPrice: i.unit_price || 0,
          order: i._order,
        })
      }
    })

    return Object.values(map)
  } catch (err) {
    console.error('Error fetching recipe cards:', err)
    return [] // مهم: هیچ وقت reject نده تا پنل crash نکند
  }
})
// برای id یکتا در ingredients

// ایجاد رسپی کارت جدید

ipcMain.handle('create-recipe', (event, payload) => {
  return new Promise((resolve, reject) => {
    const { menuItemId, ingredients } = payload;

    db.serialize(() => {
      db.run('BEGIN TRANSACTION');

      // 1. اضافه کردن کارت رسپی
      db.run(
        `INSERT INTO recepcard (menu_item_id) VALUES (?)`,
        [menuItemId],
        function (err) {
          if (err) {
            db.run('ROLLBACK');
            return reject(err);
          }

          const cardId = this.lastID;

          // 2. اضافه کردن مواد اولیه
          const stmt = db.prepare(
            `INSERT INTO recepcard_ingredients (_order, _parent_id, id, material_id, quantity)
             VALUES (?, ?, ?, ?, ?)`
          );

          ingredients.forEach((ing, idx) => {
            stmt.run(idx + 1, cardId, uuidv4(), ing.material_id, ing.quantity);
          });

          stmt.finalize((err) => {
            if (err) {
              db.run('ROLLBACK');
              return reject(err);
            }

            db.run('COMMIT', (err) => {
              if (err) return reject(err);
              resolve({ success: true, id: cardId }); // id کارت جدید را برمی‌گردانیم
            });
          });
        }
      );
    });
  });
});

// بروزرسانی رسپی کارت
ipcMain.handle('update-recipe', (event, payload) => {
  return new Promise((resolve, reject) => {
    const { id, ingredients } = payload;

    db.serialize(() => {
      db.run('BEGIN TRANSACTION');

      // حذف مواد اولیه قبلی
      db.run(`DELETE FROM recepcard_ingredients WHERE _parent_id = ?`, [id], (err) => {
        if (err) {
          db.run('ROLLBACK');
          return reject(err);
        }

        // اضافه کردن مواد جدید
        const stmt = db.prepare(
          `INSERT INTO recepcard_ingredients (_order, _parent_id, id, material_id, quantity)
           VALUES (?, ?, ?, ?, ?)`
        );

        ingredients.forEach((ing, idx) => {
          stmt.run(idx + 1, id, uuidv4(), ing.material_id, ing.quantity);
        });

        stmt.finalize((err) => {
          if (err) {
            db.run('ROLLBACK');
            return reject(err);
          }
          db.run('COMMIT', (err) => {
            if (err) return reject(err);
            resolve({ success: true });
          });
        });
      });
    });
  });
});
// حذف رسپی کارت
ipcMain.handle('delete-recipe', async (event, id) => {
  try {
    await new Promise((resolve, reject) => {
      db.run(`DELETE FROM recepcard WHERE id = ?`, [id], (err) =>
        err ? reject(err) : resolve()
      );
    });
    // ingredients خودکار cascade حذف می‌شوند
    return { success: true };
  } catch (err) {
    console.error('Error deleting recipe:', err);
    throw err;
  }
});


ipcMain.handle('admin-login', async (event, { username, password }) => {
  try {
    const res = await fetch('https://shahbazgc.ir/api/users/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      return {
        success: false,
        message: data.errors?.[0]?.message || 'خطا در ورود',
      };
    }

    // بررسی نقش
    if (data.user.role !== 'admin') {
      return {
        success: false,
        message: 'دسترسی ادمین ندارید',
      };
    }

    return {
      success: true,
      token: data.token, // JWT
      user: data.user,
    };

  } catch (err) {
    return {
      success: false,
      message: 'خطای ارتباط با سرور',
    };
  }
});



// ثبت فاکتور 
ipcMain.handle('create-factor', async (event, { orders, offer, name }) => {

  return new Promise(async (resolve, reject) => {
    const sum = orders.reduce((total, item) => total + (item.paid), 0);
    const paid = sum - offer * sum / 100;
    const sql = `
      INSERT INTO factororder (total, offer, paid, name)
      VALUES (?, ?, ?, ?)`;
    const result = await db.run(sql, [sum, offer, paid, name || null], function (err) {
      if (err) {
        reject(err);
      } else {

        const factorId = this.lastID;
        // ذخیره سفارش‌ها
        const insertOrder = db.prepare(`
      INSERT INTO factororder_orders (_order, _parent_id, id, product, quantity, price)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

        orders.forEach((item, index) => {
          insertOrder.run(
            index + 1,                 // شماره ردیف
            factorId,                 // شناسه والد
            uuidv4(),      // id سفارش
            item.title,
            item.quantity,
            item.price
          );
        });

        resolve({ success: true, id: factorId });
      }

    });



  });
});

// لیست پرینترها
ipcMain.handle('get-printers', async () => {
  const win = BrowserWindow.getAllWindows()[0];
  if (!win) return { printers: [], defaultPrinter: null };

  const printers = await win.webContents.getPrintersAsync();

  // جستجوی پرینتر با نام POS-90
  const posPrinter = printers.find(p => p.name === 'POS-90');

  // اگر POS-90 پیدا شد، همون رو پیش‌فرض کن؛ در غیر این صورت اولین پرینتر
  const defaultPrinter = posPrinter || printers[0] || null;
  return {
    printers,
    defaultPrinter
  };
});

// چاپ کردن
ipcMain.handle('print-order', async (event, { preview, printerName, tableName, factorNumber, offer, date, time, items }) => {
  const total = items.reduce((sum, i) => sum + i.paid, 0);
  const discount = total * offer / 100;
  const payable = total - discount;

  // ساخت HTML پرینت
  const content = `
    <html dir="ltr">
        <head>
      <meta charset="UTF-8" />
      <style>
        @page {
          size: 80mm 0;
          margin: 0;
        }
        body {
          width: 70mm;
          margin: 0;
          top:0;
          font-family: Tahoma, sans-serif;
          font-size: 8px;
          direction: ltr;
        }
        h2, h4 {
          text-align: center;
          margin: 8px 0;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 6px;
        }
        th, td {
          border: 0.5px solid #000;
          padding: 6px 1.5px;
          text-align: center;
          word-break: break-word;
          font-size:10px;
        }
        .footer td {
          border: 0.5px solid #000;
          padding: 6px 1.5px;
          text-align: right;
          word-break: break-word;
          font-size:14px;
        }
      </style>
    </head>
      <body>
        <div dir="rtl">
        <h2>باشگاه بازی فکری شهباز</h2>
        <h4>شماره فاکتور: ${factorNumber} &nbsp;&nbsp;&nbsp; تاریخ: ${date} - ${time}</h4>        
        <table>
          <thead>
            <tr>
              <th>ردیف</th>
              <th>عنوان</th>
              <th>قیمت</th>
              <th>تعداد</th>
              <th>جمع</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((item, index) => `
              <tr>
                <td>${index + 1}</td>
                <td>${item.title}</td>
                <td>${item.price.toLocaleString()}</td>
                <td>${item.quantity}</td>
                <td>${(item.paid * 1000).toLocaleString()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        <table style="margin-top: 16px;">
          <tr class="footer"><td>مبلغ کل:</td><td>${(total * 1000).toLocaleString()} تومان</td></tr>
          <tr class="footer"><td>تخفیف:</td><td>${(discount * 1000).toLocaleString()} تومان</td></tr>
          <tr class="footer"><td><strong>قابل پرداخت:</strong></td><td><strong>${(payable * 1000).toLocaleString()} تومان</strong></td></tr>
        </table>
        </div>
      </body>
    </html>
  `;
  const contentPrivew = `
    <html dir="ltr">
          <head>
      <meta charset="UTF-8" />
      <style>
        @page {
          size: 80mm 0;
          margin: 0;
        }
        body {
          width: 70mm;
          margin: 0;
          top:0;
          font-family: Tahoma, sans-serif;
          font-size: 8px;
          direction: ltr;
        }
        h2, h4 {
          text-align: center;
          margin: 8px 0;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 6px;
        }
        th, td {
          border: 0.5px solid #000;
          padding: 3px 1.5px;
          text-align: center;
          word-break: break-word;
          font-size:10px;
        }
        .footer td {
          border: 0.5px solid #000;
          padding: 6px 1.5px;
          text-align: right;
          word-break: break-word;
          font-size:14px;
        }
      </style>
    </head>
      <body>
      <div dir="rtl">
        <h4>شماره فاکتور: ${factorNumber} &nbsp;&nbsp;&nbsp; تاریخ: ${date} - ${time}</h4>  
        <h4> اسم میز : ${tableName}</h4>      
        <table>
          <thead>
            <tr>
              <th>ردیف</th>
              <th>عنوان</th>
              <th>تعداد</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((item, index) => `
              <tr>
                <td>${index + 1}</td>
                <td>${item.title}</td>
                <td>${item.quantity}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        </div>
      </body>
    </html>
  `;
  // ایجاد پنجره مخفی برای چاپ
  const printWindow = new BrowserWindow({ show: false });
  if (preview)
    printWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(contentPrivew)}`);
  else
    printWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(content)}`);

  printWindow.webContents.on('did-finish-load', () => {
    printWindow.webContents.print({
      silent: true,
      deviceName: printerName,
      margins: {
        marginType: 'custom',
        top: 0,
        bottom: 0,
        left: 0,
        right: 0
      },
    }, (success, errorType) => {
      if (!success) console.error('خطا در چاپ:', errorType);
      printWindow.close();
    });
  });
});




ipcMain.handle('excel-order', async (event, { factorNumber, time, items, offer, tableName }) => {
  const ExcelJS = require('exceljs');
  const fs = require('fs');
  const path = require('path');

  const total = items.reduce((sum, i) => sum + i.paid, 0);
  const discount = total * offer / 100;
  const payable = total - discount;

  // ساخت تاریخ شمسی
  const now = new Date();
  const faParts = new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
    year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(now);

  const dateObj = {};
  faParts.forEach(part => {
    if (part.type !== 'literal') {
      dateObj[part.type] = part.value.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
    }
  });

  const year = dateObj.year;
  const month = dateObj.month;
  const day = dateObj.day;
  const sheetName = `${year}-${month}-${day}`;

  const fileName = `factor-${year}-${month}.xlsx`;

  const excelDir = path.join('E:/', 'excel');
  if (!fs.existsSync(excelDir)) {
    fs.mkdirSync(excelDir, { recursive: true });
  }
  const filePath = path.join(excelDir, fileName);

  const workbook = new ExcelJS.Workbook();

  if (fs.existsSync(filePath)) {
    await workbook.xlsx.readFile(filePath);
  }

  let sheet = workbook.getWorksheet(sheetName);
  if (!sheet) {
    sheet = workbook.addWorksheet(sheetName);

    // تعیین ستون‌ها با عرض مناسب
    sheet.columns = [
      { header: 'شماره فاکتور', key: 'factor', width: 20 },
      { header: 'زمان', key: 'time', width: 15 },
      { header: 'نام میز', key: 'table', width: 20 },
      { header: 'مجموع سفارشات', key: 'total', width: 18 },
      { header: 'تخفیف', key: 'discount', width: 18 },
      { header: 'مبلغ پرداختی', key: 'payable', width: 18 },
    ];

    // اعمال استایل وسط‌چین + فونت B Zar روی هدر
    sheet.getRow(1).eachCell(cell => {
      cell.font = { name: 'B Zar', bold: true, size: 12 };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
    });
  }

  // افزودن ردیف جدید
  const newRow = sheet.addRow([factorNumber, time, tableName, total * 1000, discount * 1000, payable * 1000]);
  newRow.eachCell(cell => {
    cell.font = { name: 'B Zar', size: 12 };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    // اگر می‌خواهید نمایش هزارگان فعال شود، می‌توانید اینجا فرمت عدد بگذارید:
    if (['D', 'E', 'F'].includes(cell.address[0])) { // ستون‌های مجموع سفارشات، تخفیف و پرداختی
      cell.numFmt = '#,##0';
    }
  });
  const lastRow = sheet.lastRow.number;
  sheet.getColumn('H').width = 20; // عرض ستون تخفیف‌ها
  sheet.getColumn('I').width = 20; // عرض ستون پرداختی‌ها

  sheet.getCell('H2').value = 'مبلغ کل پرداختی'

  sheet.getCell('I2').value = {
    formula: `SUM(F2:F${lastRow})`, // مجموع پرداختی‌ها
    result: null
  };

  // استایل زیبا و وسط‌چین برای این سلول‌ها
  ['H2', 'I2'].forEach(cellAddress => {
    const cell = sheet.getCell(cellAddress);
    cell.font = { name: 'B Zar', bold: true, size: 12 };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
  });
  const cellI2 = sheet.getCell('I2');
  cellI2.numFmt = '#,##0';

  // اضافه کردن گزارش ماهانه پس از ثبت ردیف فاکتور
  let monthlySheet = workbook.getWorksheet('گزارش ماهانه');
  if (!monthlySheet) {
    monthlySheet = workbook.addWorksheet('گزارش ماهانه');

    // هدر جدول
    monthlySheet.addRow([
      'تاریخ', 'سفارش', 'خرید', 'مانده', 'پوز سامان',
      'پوز اقتصاد نوین', 'کارت به کارت', 'نقدی', 'مجموع دریافتی', 'اختلاف'
    ]);

    // اعمال استایل هدر
    monthlySheet.getRow(1).eachCell(cell => {
      cell.font = { name: 'B Zar', bold: true, size: 12 };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
    });

    // گرفتن تعداد روزهای ماه جاری (برای تقویم شمسی)
    const daysInMonth = getJalaliMonthDays();// می‌توانید این را بر اساس ماه دقیق محاسبه کنید
    for (let d = 1; d <= daysInMonth; d++) {
      const paddedDay = String(d).padStart(2, '0');
      const faDate = `${year}-${month}-${paddedDay}`;

      const row = monthlySheet.addRow([
        faDate, 0, 0, 0, 0, 0, 0, 0, 0, 0
      ]);

      row.eachCell(cell => {
        cell.font = { name: 'B Zar', size: 12 };
        cell.alignment = { horizontal: 'center', vertical: 'middle' };
      });

      const rowIndex = row.number;

      // 👉 سفارش از سلول I2 در شیت با نام تاریخ اون روز
      monthlySheet.getCell(`B${rowIndex}`).value = {
        formula: `='${faDate}'!I2`,
        result: null
      };
      // فرمول مانده = سفارش - خرید
      monthlySheet.getCell(`D${rowIndex}`).value = {
        formula: `B${rowIndex}-C${rowIndex}`,
        result: null
      };

      // مجموع دریافتی = جمع 4 ستون دریافتی
      monthlySheet.getCell(`I${rowIndex}`).value = {
        formula: `E${rowIndex}+F${rowIndex}+G${rowIndex}+H${rowIndex}`,
        result: null
      };

      // اختلاف = سفارش - مجموع دریافتی
      monthlySheet.getCell(`J${rowIndex}`).value = {
        formula: `B${rowIndex}-I${rowIndex}`,
        result: null
      };
    }

    // تعیین عرض مناسب ستون‌ها
    ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'].forEach(col => {
      monthlySheet.getColumn(col).width = 18;
    });
  }
  await workbook.xlsx.writeFile(filePath);
  return filePath;
});

