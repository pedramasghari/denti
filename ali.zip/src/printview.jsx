import React, { useState, useEffect } from 'react';
const { ipcRenderer } = window.require('electron');
const ps_price=[150,250];
const gb_price=50;
// کامپوننت سفارش‌ها
function GetOrderByTable({ table, offer, onItemsChange }) {
  const [orderItems, setOrderItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const updateQuantity = (id, newQuantity) => {
    setOrderItems((prev) => {
      const updated = prev.map((item) => {
        if (item.id === id) {
          const quantity = Math.max(1, newQuantity); // حداقل مقدار ۱
          const isGame = /پلی‌استیشن |بردگیم/i.test(item.title);
          const paid = isGame
            ? Math.floor(Number(item.price) * quantity / 60)
            : Number(item.price) * quantity;

          return { ...item, quantity, paid };
        }
        return item;
      });
      onItemsChange(updated);
      return updated;
    });
  };

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true);
        setError(null);

        const orders = await ipcRenderer.invoke('get-orders-by-table', table.id);
        const mappedOrders = orders.map((order) => {
          const isGame = /پلی‌استیشن |بردگیم/i.test(order.product);
          let paidcount = 0;
          if (isGame) { paidcount = Math.floor(Number(order.price) * Number(order.quantity) / 60) }
          else { paidcount = Number(order.price) * Number(order.quantity) }
          return ({
            id: order.id,
            title: order.product,
            price: order.price,
            quantity: order.quantity,
            paid: paidcount,
            print: true, // چاپ فعال به صورت پیش‌فرض
          })
        });

        const gameOrders = await ipcRenderer.invoke('get-game-orders-by-table', table.id);
        gameOrders.forEach((order) => {
          if (order.start_time && !order.end_time) {
            const start = new Date(order.start_time);
            const diff = Math.floor((Date.now() - start.getTime()) / 60000);
            if (diff > 0) {
              const title = order.type === 'ps'
                ? `پلی‌استیشن ${order.controllers_or_players} دسته`
                : `بردگیم ${order.controllers_or_players} نفره`;
              const price = order.type === 'ps'
                ? (order.controllers_or_players === 2 ? ps_price[0] : ps_price[1])
                : (order.controllers_or_players * gb_price);

              mappedOrders.push({
                id: `game-${order.id}`,
                title,
                price,
                quantity: diff,
                paid: Math.floor(price * diff / 60),
                print: true,
              });
            }
          }
        });

        setOrderItems(mappedOrders);
        onItemsChange(mappedOrders); // ارسال لیست به والد
      } catch (err) {
        setError('خطا در دریافت سفارش‌ها');
      } finally {
        setLoading(false);
      }
    };

    if (table?.id) {
      fetchOrders();
    }
  }, [table, onItemsChange]);

  const togglePrint = (id) => {
    setOrderItems((prev) => {
      const updated = prev.map((item) =>
        item.id === id ? { ...item, print: !item.print } : item
      );
      onItemsChange(updated);
      return updated;
    });
  };

  if (loading) return <div className="text-center p-4 text-gray-500">در حال بارگذاری...</div>;
  if (error) return <div className="text-center p-4 text-red-500">{error}</div>;
  if (orderItems.length === 0) return <div className="text-center p-4 text-gray-400">هیچ سفارشی ثبت نشده</div>;

  return (
    <>
      <div className="flex-grow overflow-y-scroll ">
        <table className="w-full text-black text-sm table-auto border border-gray-300 mt-2 ">
          <thead className="bg-gray-100">
            <tr>
              <th className="border px-2 py-1">نام محصول</th>
              <th className="border px-2 py-1">تعداد</th>
              <th className="border px-2 py-1">قیمت واحد</th>
              <th className="border px-2 py-1">مجموع</th>
              <th className="border px-2 py-1">چاپ</th>
            </tr>
          </thead>
          <tbody>
            {orderItems.map((item) => (
              <tr key={item.id} className="text-center">
                <td className="border px-2 py-1">{item.title}</td>
                <td className="border px-2 py-1">
                  <input
                    type="number"
                    min="1"
                    className="w-16 text-center border rounded"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                  />
                </td>

                <td className="border px-2 py-1">
                  {item.price.toLocaleString()}
                </td>
                <td className="border px-2 py-1">
                  {item.paid.toLocaleString()} تومان{" "}
                </td>
                <td className="border px-2 py-1">
                  <input
                    type="checkbox"
                    checked={item.print}
                    onChange={() => togglePrint(item.id)}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className='flex flex-row justify-between px-4'>
        <h2>
          مجموع سفارشات :{" "}
          {orderItems
            .reduce((total, item) => total + item.paid, 0)
            .toLocaleString()}{" "}
          تومان{" "}
        </h2>
        <h2>
          تخفیف :{" "}
          {(orderItems
            .reduce((total, item) => total + item.paid, 0) * offer / 100
          ).toLocaleString()}{" "}
          تومان{" "}
        </h2>
        <h2>
          مجموع پرداختی :{" "}
          {(orderItems
            .reduce((total, item) => total + item.paid, 0) * (1 - offer / 100)
          ).toLocaleString()}{" "}
          تومان{" "}
        </h2>
      </div>
    </>
  );
}

// صفحه اصلی چاپ
export default function PrintView({ offer, table, preview, onClose }) {
  const [printers, setPrinters] = useState([]);
  const [selectedPrinter, setSelectedPrinter] = useState('');
  const [printItems, setPrintItems] = useState([]);

  useEffect(() => {
    const fetchPrinters = async () => {
      const printerInfo = await ipcRenderer.invoke('get-printers');
      setPrinters(printerInfo.printers);
      setSelectedPrinter(printerInfo.defaultPrinter?.name);
    };
    fetchPrinters();
  }, []);

  const handlePrint = async () => {
    const itemsToPrint = printItems.filter((item) => item.print);
     const now = new Date(); // شماره فاکتور تصادفی
    if (itemsToPrint.length === 0) {
      alert('هیچ آیتمی برای چاپ انتخاب نشده');
      return;
    }
    try {
      let factorNumber=1
      if(!preview)
      {
      const factor = await ipcRenderer.invoke('create-factor', {
        orders: itemsToPrint,
        offer,
        name: table.name
      });
      if (!factor.success) {
        alert('خطا در ثبت فاکتور: ' + factor.error);
        return;
      }
      factorNumber=factor.id
      ipcRenderer.invoke('excel-order', {
        tableName: table?.name,
        factorNumber,
        offer,
        date: now.toLocaleDateString('fa-IR'),
        time: now.toLocaleTimeString('fa-IR'),
        items: itemsToPrint,
      });
      await ipcRenderer.invoke('delete-table', table.id);
      }
     

      ipcRenderer.invoke('print-order', {
        preview,
        printerName: selectedPrinter,
        tableName: table?.name,
        factorNumber,
        offer,
        date: now.toLocaleDateString('fa-IR'),
        time: now.toLocaleTimeString('fa-IR'),
        items: itemsToPrint,
      });
      
       
      onClose();
    } catch (error) { }

  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
      <div className="w-[80%] h-[80%] bg-white rounded-lg shadow-lg p-4 flex flex-col relative">
        <div className="flex justify-between items-center mb-4 w-full">
          <div className="flex ms-4 gap-2">
            <span className="my-auto">انتخاب پرینتر</span>
            <select
              className="w-auto border border-gray-300 rounded px-4 py-1"
              value={selectedPrinter}
              onChange={(e) => setSelectedPrinter(e.target.value)}
            >
              {printers.map((printer) => (
                <option key={printer.name} value={printer.name}>
                  {printer.name}
                </option>
              ))}
            </select>
          </div>
          <div className="flex gap-4 me-4 ms-auto">
            <button
              onClick={onClose}
              className="bg-gray-300 text-gray-800 px-4 py-1 rounded"
            >
              بستن
            </button>
            <button
              onClick={handlePrint}
              className="bg-teal-600 text-white px-4 py-1 rounded"
            >
              چاپ
            </button>
          </div>
        </div>
        <h1 className="text-xl font-bold text-center text-gray-700 mb-4">
          پیش‌نمایش چاپ - {table?.name || "بدون نام"}
        </h1>
        <GetOrderByTable offer={offer} table={table} onItemsChange={setPrintItems} />

      </div>
    </div>
  );
}
