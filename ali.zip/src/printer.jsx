import React, { useEffect, useState } from 'react';

const PrinterSelector = () => {
  const [printers, setPrinters] = useState([]);
  const [selectedPrinter, setSelectedPrinter] = useState('');
  const [silent, setSilent] = useState(false);

  useEffect(() => {
    window.electronAPI.getPrinters().then((list) => {
      const posPrinters = list.filter(p => p.name.toLowerCase().includes('pos'));
      setPrinters(posPrinters);
      if (posPrinters.length > 0) setSelectedPrinter(posPrinters[0].name);
    });
  }, []);

  const handlePrint = () => {
    if (!selectedPrinter) return alert('لطفاً یک پرینتر انتخاب کنید.');

    window.electronAPI.print({
      deviceName: selectedPrinter,
      silent,
    });
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-bold">انتخاب پرینتر:</h2>
      <select
        className="border rounded p-2"
        value={selectedPrinter}
        onChange={(e) => setSelectedPrinter(e.target.value)}
      >
        {printers.map((printer) => (
          <option key={printer.name} value={printer.name}>
            {printer.name}
          </option>
        ))}
      </select>

      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={silent}
          onChange={(e) => setSilent(e.target.checked)}
        />
        چاپ بی‌صدا (بدون دیالوگ)
      </label>

      <button
        onClick={handlePrint}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        چاپ سفارشات
      </button>
    </div>
  );
};

export default PrinterSelector;
