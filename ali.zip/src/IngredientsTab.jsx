import React, { useEffect, useState } from 'react';
const { ipcRenderer } = window.require('electron');
import { SmartSingleSelect } from './components/fields';

export default function IngredientsTab() {
  const [categories, setCategories] = useState([]);
  const [materials, setMaterials] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('');
  const [newCategoryName, setNewCategoryName] = useState('');
  const [renameCategory, setRenameCategory] = useState('');

  const [deletePreview, setDeletePreview] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);


  const [editingMaterial, setEditingMaterial] = useState(null);
  const [materialForm, setMaterialForm] = useState({
    name: '',
    categoryId: '',
    measureType: 'weight',
    unit: 'kg',
    stock: 0,
    unitPrice: 0,
    isComposite: false,
    unitYield: 1,
    components: [], // ترکیبات برای مواد ترکیبی
  });

  // --- داده‌ها ---
  const fetchCategories = async () => {
    setLoading(true);
    try {
      const cats = await ipcRenderer.invoke('get-material-categories');
      setCategories(cats);
      if (!activeTab && cats.length) setActiveTab(cats[0].id);
      const activeCat = cats.find(c => c.id === activeTab);
      setRenameCategory(activeCat?.name || '');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMaterials = async () => {
    setLoading(true);
    try {
      const mats = await ipcRenderer.invoke('get-materials');
      setMaterials(mats);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
    useEffect(() => {
  ipcRenderer.on('backend-log', (_, log) => {
    if (log.level === 'error') {
      console.error('🟥 BACKEND:', log.payload);
    } else {
      console.log('🟦 BACKEND:', log.payload);
    }
  });

  return () => {
    ipcRenderer.removeAllListeners('backend-log');
  };
}, []);
  useEffect(() => {
    fetchCategories();
    fetchMaterials();
  }, []);
  useEffect(() => {
  window.require('electron').ipcRenderer.on('log', (_, msg) => {
    console.log(msg);
  });
}, []);

  useEffect(() => {
    const activeCat = categories.find(c => c.id === activeTab);
    setRenameCategory(activeCat?.name || '');
    resetForm();
  }, [activeTab, categories]);
  // --------------------------------

  const handleCategoryDelete = async () => {
  const res = await ipcRenderer.invoke(
    'prepare-delete-material-category',
    activeTab
  );

  if (!res.success) {
    alert('خطا در آماده‌سازی حذف');
    return;
  }

  setDeletePreview(res);
  setShowDeleteModal(true);
};


  // --- مدیریت فرم ---
  const handleFormChange = (field, value) => {
    setMaterialForm(prev => ({ ...prev, [field]: value }));
  };

  const resetForm = () => {
    setEditingMaterial(null);
    setMaterialForm({
      name: '',
      categoryId: '',
      measureType: 'weight',
      unit: 'kg',
      stock: 0,
      unitPrice: 0,
      isComposite: false,
      unitYield: 1,
      components: [],
    });
  };

  // --- مدیریت ترکیبات ---
  const addComponent = () => {
    setMaterialForm(prev => ({
      ...prev,
      components: [...prev.components, { materialId: '', quantity: 0 }]
    }));
  };

  const removeComponent = (idx) => {
    setMaterialForm(prev => ({
      ...prev,
      components: prev.components.filter((_, i) => i !== idx)
    }));
  };

  const handleComponentChange = (idx, field, value) => {
    setMaterialForm(prev => ({
      ...prev,
      components: prev.components.map((comp, i) =>
        i === idx ? { ...comp, [field]: value } : comp
      )
    }));
  };

  // --- محاسبه قیمت واحد برای مواد ترکیبی ---
  const computeUnitPrice = (form) => {
    if (!form.isComposite) return form.unitPrice;
    let totalCost = 0;
    form.components.forEach(c => {
      const mat = materials.find(m => m.id === c.materialId);
      if (mat) totalCost += mat.unitPrice * c.quantity;
    });
    return form.unitYield ? totalCost / form.unitYield : 0;
  };

  // --- ذخیره ماده ---
  const handleMaterialSave = async () => {
    setLoading(true);
    try {
      if (!materialForm.categoryId) materialForm.categoryId = activeTab;

      const payload = {
        ...materialForm,
        unitPrice: materialForm.isComposite ? computeUnitPrice(materialForm) : materialForm.unitPrice
      };

      if (editingMaterial) {
        await ipcRenderer.invoke('update-material', { ...payload, id: editingMaterial.id });
      } else {
        await ipcRenderer.invoke('create-material', payload);
      }

      resetForm();
      await fetchMaterials();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleMaterialEdit = (mat) => {
    setEditingMaterial(mat);
    setMaterialForm({
      name: mat.name,
      categoryId: mat.categoryId || '',
      measureType: mat.measureType,
      unit: mat.unit,
      stock: mat.stock,
      unitPrice: mat.unitPrice,
      isComposite: mat.isComposite || false,
      unitYield: mat.unitYield || 1,
      components: mat.components || [],
    });
  };

 const handleMaterialDelete = async (mat) => {
  console.log(mat)
  const res = await ipcRenderer.invoke('check-material-usage', mat.id);

  if (!res.success) {
    alert('خطا در بررسی وابستگی‌ها');
    return;
  }

  if (res.usedInComposites.length || res.usedInRecipes.length) {
    let msg = '⚠️ این ماده در موارد زیر استفاده شده:\n\n';

    if (res.usedInComposites.length) {
      msg += 'مواد ترکیبی:\n';
      res.usedInComposites.forEach(m => {
        msg += `- ${m.name}\n`;
      });
    }

    if (res.usedInRecipes.length) {
      msg += '\nرسپی‌ها:\n';
      res.usedInRecipes.forEach(r => {
        msg += `- ${r.menuTitle}\n`;
      });
    }

    msg += '\nآیا حذف شود و از همه این موارد پاک شود؟';

    if (!confirm(msg)) return;
  }

  await ipcRenderer.invoke('delete-material-force', mat.id);
  alert('ماده با موفقیت حذف شد');
  await fetchMaterials();
};


  const activeMaterials = activeTab === 'new' ? [] : materials.filter(m => m.categoryId === activeTab);

  // --- جلوگیری از ترکیب تکراری ---
  const usedMaterialIds = materialForm.components.map(c => c.materialId);

  return (
    <div>
      <h3 className="mb-2 font-bold">مدیریت مواد اولیه با تب‌بندی</h3>

      {/* تب‌ها */}
      <div className="flex gap-2 mb-2 flex-wrap">
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveTab(cat.id)}
            className={`px-4 py-2 rounded ${activeTab===cat.id ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
          >
            {cat.name}
          </button>
        ))}
        <button
          onClick={() => setActiveTab('new')}
          className={`px-4 py-2 rounded ${activeTab==='new' ? 'bg-green-500 text-white' : 'bg-gray-200'}`}
        >
          + اضافه کردن دسته‌بندی
        </button>
      </div>
        {activeTab === 'new' && (
  <div className="mb-4 border p-4 rounded shadow">
    <h4 className="font-bold mb-2">ایجاد دسته‌بندی جدید</h4>

    <div className="mb-2">
      <label className="font-medium text-gray-700 mb-1 block">
        نام دسته‌بندی
      </label>
      <input
        type="text"
        className="border p-2 rounded w-full"
        value={newCategoryName}
        onChange={e => setNewCategoryName(e.target.value)}
      />
    </div>

    <button
      onClick={async () => {
        if (!newCategoryName.trim()) return;

        setLoading(true);
        await ipcRenderer.invoke(
          'create-material-category',
          newCategoryName.trim()
        );

        setNewCategoryName('');
        await fetchCategories();
        setActiveTab('');
        setLoading(false);
      }}
      className="bg-green-600 text-white px-4 py-2 rounded"
    >
      ثبت دسته‌بندی
    </button>
  </div>
)}
  {activeTab !== 'new' && !showDeleteModal && (
  <div className="mb-4 border p-4 rounded shadow flex flex-col md:flex-row gap-2">
    <div className="flex-grow">
      <label className="font-medium text-gray-700 mb-1 block">
        نام دسته‌بندی
      </label>
      <input
        type="text"
        className="border p-2 rounded w-full"
        value={renameCategory}
        onChange={e => setRenameCategory(e.target.value)}
      />
    </div>

    <div className="flex gap-2 items-end">
      <button
        onClick={async () => {
          if (!renameCategory.trim()) return;

          setLoading(true);
          await ipcRenderer.invoke('update-material-category', {
            id: activeTab,
            name: renameCategory.trim(),
          });
          await fetchCategories();
          setLoading(false);
        }}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        ذخیره نام
      </button>

      <button
        onClick={handleCategoryDelete}
        className="bg-red-600 text-white px-4 py-2 rounded"
      >
        حذف دسته‌بندی
      </button>
    </div>
  </div>
)}

      {/* جدول مواد */}
      {!loading && activeTab !== 'new' && !showDeleteModal && (
        <>
          <table className="w-full border text-center mb-4">
            <thead>
              <tr>
                <th className="border px-2 py-1">نام ماده</th>
                <th className="border px-2 py-1">نوع اندازه‌گیری</th>
                <th className="border px-2 py-1">واحد</th>
                <th className="border px-2 py-1">موجودی</th>
                <th className="border px-2 py-1">قیمت واحد</th>
                <th className="border px-2 py-1">ترکیبی؟</th>
                <th className="border px-2 py-1">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {activeMaterials.map(mat => (
                <tr key={mat.id}>
                  <td className="border px-2 py-1">{mat.name}</td>
                  <td className="border px-2 py-1">{mat.measureType}</td>
                  <td className="border px-2 py-1">{mat.unit}</td>
                  <td className="border px-2 py-1">{mat.stock}</td>
                  <td className="border px-2 py-1">{mat.unitPrice.toLocaleString()}</td>
                  <td className="border px-2 py-1">{mat.isComposite ? 'بله' : 'خیر'}</td>
                  <td className="border px-2 py-1">
                    <button className="bg-yellow-400 px-2 rounded mr-2" onClick={()=>handleMaterialEdit(mat)}>ویرایش</button>
                    <button className="bg-red-500 px-2 rounded" onClick={()=>handleMaterialDelete(mat)}>حذف</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* فرم اضافه/ویرایش ماده */}
          <div key={editingMaterial?.id || 'new-material'} className="mb-4 border p-4 rounded shadow">
            <h4 className="font-bold mb-2">{editingMaterial ? 'ویرایش ماده' : 'اضافه کردن ماده'}</h4>

            <div className="mb-2">
              <label className="font-medium text-gray-700 mb-1 block">نام ماده</label>
              <input
                type="text"
                className="border p-2 rounded w-full"
                value={materialForm.name}
                onChange={e => handleFormChange('name', e.target.value)}
              />
            </div>

            <div className="mb-2">
              <label className="font-medium text-gray-700 mb-1 block">دسته‌بندی</label>
              <select
                className="border p-2 rounded w-full"
                value={materialForm.categoryId}
                onChange={e => handleFormChange('categoryId', e.target.value)}
              >
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div className="flex gap-2 flex-wrap">
              <div className="mb-2 flex-grow">
                <label className="font-medium text-gray-700 mb-1 block">نوع اندازه‌گیری</label>
                <select
                  className="border p-2 rounded w-full"
                  value={materialForm.measureType}
                  onChange={e => handleFormChange('measureType', e.target.value)}
                >
                  <option value="weight">وزن</option>
                  <option value="volume">حجم</option>
                  <option value="count">تعداد</option>
                </select>
              </div>

              <div className="mb-2 flex-grow">
                <label className="font-medium text-gray-700 mb-1 block">واحد</label>
                <select
                  className="border p-2 rounded w-full"
                  value={materialForm.unit}
                  onChange={e => handleFormChange('unit', e.target.value)}
                >
                  <option value="kg">کیلوگرم</option>
                  <option value="g">گرم</option>
                  <option value="l">لیتر</option>
                  <option value="ml">میلی‌لیتر</option>
                  <option value="piece">عدد</option>
                </select>
              </div>

              <div className="mb-2 flex-grow">
                <label className="font-medium text-gray-700 mb-1 block">موجودی</label>
                <input
                  type="number"
                  className="border p-2 rounded w-full"
                  value={materialForm.stock}
                  onChange={e => handleFormChange('stock', Number(e.target.value))}
                />
              </div>

              <div className="mb-2 flex-grow">
                <label className="font-medium text-gray-700 mb-1 block">قیمت واحد</label>
                <input
                  type="number"
                  className="border p-2 rounded w-full"
                  value={materialForm.unitPrice}
                  onChange={e => handleFormChange('unitPrice', Number(e.target.value))}
                  disabled={materialForm.isComposite}
                />
              </div>
            </div>

            {/* ماده ترکیبی */}
            <div className="mb-2">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={materialForm.isComposite}
                  onChange={e => handleFormChange('isComposite', e.target.checked)}
                />
                ماده ترکیبی؟
              </label>
            </div>

            {materialForm.isComposite && (
              <>
                <div className="mb-2">
                  <label className="font-medium text-gray-700 mb-1 block">واحد خروجی (Unit Yield)</label>
                  <input
                    type="number"
                    className="border p-2 rounded w-full"
                    value={materialForm.unitYield}
                    onChange={e => handleFormChange('unitYield', Number(e.target.value))}
                  />
                </div>

                <h5 className="font-bold mb-2">ترکیبات</h5>
                {materialForm.components.map((comp, idx) => (
                  <div key={idx} className="flex flex-wrap gap-2 items-center mb-2 border p-2 rounded">
                    <SmartSingleSelect
                      label="ماده اولیه"
                      options={materials
                        .filter(m => !m.isComposite && !usedMaterialIds.includes(m.id) || m.id === comp.materialId)
                        .map(m => ({ label: m.name, value: m.id }))}
                      value={comp.materialId ? { label: materials.find(m => m.id === comp.materialId)?.name, value: comp.materialId } : null}
                      onChange={selected => handleComponentChange(idx, 'materialId', selected?.value || '')}
                    />
                    <div className="flex flex-col">
                      <label className="font-medium text-gray-700 mb-1">مقدار</label>
                      <input
                        type="number"
                        value={comp.quantity}
                        onChange={e => handleComponentChange(idx, 'quantity', Number(e.target.value))}
                        className="border p-2 rounded w-24"
                      />
                    </div>
                    <button
                      className="bg-red-500 text-white px-3 py-1 rounded self-end"
                      onClick={() => removeComponent(idx)}
                    >
                      حذف
                    </button>
                  </div>
                ))}

                <button
                  className="bg-blue-500 text-white px-4 py-2 rounded mb-2"
                  onClick={addComponent}
                >
                  اضافه کردن ترکیب جدید
                </button>

                <div className="mb-2">
                  <label className="font-medium text-gray-700 mb-1 block">قیمت واحد (محاسبه خودکار)</label>
                  <input
                    type="number"
                    className="border p-2 rounded w-full bg-gray-100"
                    value={computeUnitPrice(materialForm)}
                    readOnly
                  />
                </div>
              </>
            )}

            <div className="flex gap-2">
              <button onClick={handleMaterialSave} className="bg-green-500 text-white px-4 py-2 rounded">
                {editingMaterial ? 'ذخیره تغییرات' : 'اضافه کردن'}
              </button>
              {editingMaterial && (
                <button onClick={resetForm} className="bg-gray-500 text-white px-4 py-2 rounded">
                  لغو
                </button>
              )}
            </div>
          </div>
        </>
      )}

      {showDeleteModal && (
  <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
    <div className="bg-white w-full max-w-2xl rounded-xl p-4">
      <h4 className="font-bold mb-2 text-red-600">
        حذف دسته‌بندی مواد اولیه
      </h4>

      <div className="text-sm max-h-80 overflow-auto space-y-2">
        <div>
          <b>مواد حذف‌شونده:</b>
          <ul className="list-disc pr-5">
            {deletePreview.materials.map(m => (
              <li key={m.id}>{m.name}</li>
            ))}
          </ul>
        </div>

        {deletePreview.usedInComposites.length > 0 && (
          <div>
            <b>تأثیر روی مواد ترکیبی:</b>
            <ul className="list-disc pr-5">
              {deletePreview.usedInComposites.map((c, i) => (
                <li key={i}>
                  {c.compositeName}
                </li>
              ))}
            </ul>
          </div>
        )}

        {deletePreview.usedInRecipes.length > 0 && (
          <div>
            <b>تأثیر روی رسپی کارت‌ها:</b>
            <ul className="list-disc pr-5">
              {deletePreview.usedInRecipes.map((r, i) => (
                <li key={i}>
                  {r.menuTitle}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="flex justify-end gap-2 mt-4">
        <button
          onClick={() => setShowDeleteModal(false)}
          className="bg-gray-400 text-white px-4 py-1 rounded"
        >
          لغو
        </button>
        <button
          onClick={async () => {
            await ipcRenderer.invoke(
              'confirm-delete-material-category',
              activeTab
            );
            setShowDeleteModal(false);
            fetchCategories();
            fetchMaterials();
          }}
          className="bg-red-600 text-white px-4 py-1 rounded"
        >
          تأیید حذف کامل
        </button>
      </div>
    </div>
  </div>
      )}

    </div>
  );
}
