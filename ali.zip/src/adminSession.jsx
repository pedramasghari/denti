const KEY = 'admin_session';

export function saveSession(data) {
  localStorage.setItem(KEY, JSON.stringify(data));
}

export function getSession() {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;

  const session = JSON.parse(raw);

  if (Date.now() > session.expiresAt) {
    localStorage.removeItem(KEY);
    return null;
  }

  return session;
}

export function clearSession() {
  localStorage.removeItem(KEY);
}
