import React,{ useState, useEffect } from 'react';
import { ipcRenderer } from 'electron';
const ps_price=[150,250];
const gb_price=50;
function TableOrderPanel({ table, onClose }) {
    const [categories, setCategories] = useState([]);
    const [activeCategoryId, setActiveCategoryId] = useState(null);
    const [items, setItems] = useState([]);
    const [orderItems, setOrderItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [psController, setPsController] = useState("2");
    const [psMinutes, setPsMinutes] = useState(0);
  
    const [bgPlayers, setBgPlayers] = useState(2);
    const [bgMinutes, setBgMinutes] = useState(0);
    const [psStarted, setPsStarted] = useState(false);
  
    const [bgStarted, setBgStarted] = useState(false);
  
    const addOrderToList = (order) => {
  
      const title = order.type === 'ps' ? `پلی‌استیشن ${order.number} دسته` : `بردگیم ${order.number} نفره`;
      setOrderItems((prev) => [
        ...prev,
        {
          id: prev.length + 1, // یا هر شناسه یکتا دیگری
          title: title,
          price: order.price || 0, // اگر قیمت دارید
          quantity: order.quantity || 1,
        },
      ]);
    };
  
  
    useEffect(() => {
      (async () => {
        try {
          setLoading(true);
          const cats = await ipcRenderer.invoke('get-menu-categories');
          setCategories(cats);
          if (cats.length > 0) {
            setActiveCategoryId(cats[0].id);
          }
  
          const previousOrders = await ipcRenderer.invoke('get-orders-by-table', table.id);
          setOrderItems(previousOrders.map((order) => ({
            id: order.id,
            title: order.product,
            price: order.price,
            quantity: order.quantity,
          })));
        } catch (err) {
          console.error('خطا در دریافت دسته‌ها یا سفارشات:', err);
          setError('خطا در دریافت اطلاعات اولیه میز');
        } finally {
          setLoading(false);
        }
      })();
    }, []);
  
    useEffect(() => {
      if (activeCategoryId === null) return;
      (async () => {
        try {
          setLoading(true);
          const its = await ipcRenderer.invoke('get-menu-items-by-category', activeCategoryId);
          setItems(its);
        } catch (err) {
          console.error('خطا در دریافت آیتم‌ها:', err);
          setError('خطا در دریافت آیتم‌های منو');
        } finally {
          setLoading(false);
        }
      })();
    }, [activeCategoryId]);
  
  
    useEffect(() => {
      (async () => {
        try {
          setLoading(true);
          const gameOrders = await ipcRenderer.invoke('get-game-orders-by-table', table.id);
  
          gameOrders.forEach(order => {
            if (order.type === 'ps') {
              if (order.start_time && !order.end_time) {
                const start = new Date(order.start_time);
                const diff = Math.floor((Date.now() - start.getTime()) / 60000);
                setPsStarted(true);
                setPsMinutes(diff);
                setPsController(order.controllers_or_players);
              }
            }
  
            if (order.type === 'bg') {
              if (order.start_time && !order.end_time) {
                const start = new Date(order.start_time);
                const diff = Math.floor((Date.now() - start.getTime()) / 60000);
                setBgStarted(true);
                setBgMinutes(diff);
                setBgPlayers(order.controllers_or_players);
              }
            }
          });
  
        } catch (err) {
          setError('خطا در دریافت اطلاعات بازی‌ها');
        } finally {
          setLoading(false);
        }
      })();
    }, [table]);
  
  
    const addItem = (item) => {
      setOrderItems((prev) => {
        const exists = prev.find((it) => it.title === item.title);
        if (exists) {
          return prev.map((it) =>
            it.title === item.title ? { ...it, quantity: it.quantity + 1 } : it
          );
        }
        return [...prev, { ...item, quantity: 1 }];
      });
    };
  
  
    const increaseQty = (id) => {
      setOrderItems((prev) =>
        prev.map((it) => (it.id === id ? { ...it, quantity: Number(it.quantity) + 1 } : it))
      );
    };
  
    const decreaseQty = (id) => {
      setOrderItems((prev) =>
        prev
          .map((it) =>
            it.id === id ? { ...it, quantity: Number(it.quantity) - 1 } : it
          )
          .filter((it) => it.quantity > 0)
      );
    };
  
    const removeItem = (id) => {
      setOrderItems((prev) => prev.filter((it) => it.id !== id));
    };
  
    const saveAndClose = async () => {
      if (psStarted) saveGameOrder('ps', true);
      if (bgStarted) saveGameOrder('bg', true);
      try {
        await ipcRenderer.invoke('save-order', {
          tableId: table.id,
          items: orderItems,
        });
        onClose(table);
      } catch (err) {
        console.error('خطا در ذخیره سفارش:', err);
        setError('خطا در ذخیره سفارش');
      }
    };
  
    const calculateStartTime = (minutes) => {
      const now = new Date();
      if (minutes === 0) return now;
      return new Date(now.getTime() - minutes * 60000);
    };
  
    // شروع پلی‌استیشن
    const saveGameOrder = async (types, Started) => {
  
      if (types === 'ps') {
        if (Started) {
          try {
            await ipcRenderer.invoke('delete-game-order', {
              tableId: table.id,
              type: types,
            });
            let startTime = calculateStartTime(psMinutes);
  
            await ipcRenderer.invoke('save-game-order', {
              tableId: table.id,
              type: types,
              controllers_or_players: Number(psController),
              minutes: psMinutes,
              startTime: startTime.toISOString()
            });
          } catch (err) {
            console.error(`خطا در ثبت ${types === 'ps' ? 'پلی‌استیشن' : 'بردگیم'}:`, err);
            setError(`خطا در ثبت ${types === 'ps' ? 'پلی‌استیشن' : 'بردگیم'}`);
          }
        } else {
  
  
          try {
            await ipcRenderer.invoke('delete-game-order', {
              tableId: table.id,
              type: types,
            });
          } catch (err) {
            console.error(`خطا در ثبت ${types === 'ps' ? 'پلی‌استیشن' : 'بردگیم'}:`, err);
            setError(`خطا در ثبت ${types === 'ps' ? 'پلی‌استیشن' : 'بردگیم'}`);
          }
          if (psMinutes > 0) {
            addOrderToList(
              {
                id: null,
                title: 'پلی‌استیشن',
                price: Number(psController) === 2 ? ps_price[0] : ps_price[1],
                quantity: psMinutes,
                type: types,
                number: Number(psController),
              }
            )
            setPsController("2");
            setPsMinutes(0);
            setPsStarted(false);
          }
        }
      }
  
  
      if (types === 'bg') {
        if (Started) {
          const controllers_or_players = bgPlayers;
          let minutes = bgMinutes;
          let startTime = calculateStartTime(minutes);
          try {
            await ipcRenderer.invoke('delete-game-order', {
              tableId: table.id,
              type: types,
            });
            await ipcRenderer.invoke('save-game-order', {
              tableId: table.id,
              type: types,
              controllers_or_players,
              minutes,
              startTime: startTime.toISOString()
            });
          } catch (err) {
            console.error(`خطا در ثبت ${types === 'ps' ? 'پلی‌استیشن' : 'بردگیم'}:`, err);
            setError(`خطا در ثبت ${types === 'ps' ? 'پلی‌استیشن' : 'بردگیم'}`);
          }
        } else {
          try {
            await ipcRenderer.invoke('delete-game-order', {
              tableId: table.id,
              type: types,
            });
          } catch (err) {
            console.error(`خطا در ثبت ${types === 'ps' ? 'پلی‌استیشن' : 'بردگیم'}:`, err);
            setError(`خطا در ثبت ${types === 'ps' ? 'پلی‌استیشن' : 'بردگیم'}`);
          }
          if (bgMinutes > 0) {
  
            addOrderToList(
              {
                id: null,
                title: 'بردگیم',
                price: bgPlayers * gb_price,
                quantity: bgMinutes,
                type: types,
                number: bgPlayers,
              }
            )
            setBgPlayers(2);
            setBgMinutes(0);
            setBgStarted(false);
          }
        }
      }
    }
    const startPs = () => {
      setPsStarted(true);
      setPsMinutes(0);
    };
  
    const endPs = () => {
      setPsStarted(false);
      saveGameOrder('ps', false);
  
    };
  
    const startBg = () => {
      setBgStarted(true);
      setBgMinutes(0);
    };
  
    const endBg = () => {
  
      setBgStarted(false);
      saveGameOrder('bg', false);
    };
  
  
  
    if (loading) {
      return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
        </div>
      );
    }
  
    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
        <div className="w-[80%] h-[80%] bg-white rounded-lg shadow-lg flex overflow-hidden">
          {/* دسته‌بندی و آیتم‌ها */}
          <div className="w-2/3 p-4 h-full border-l border-gray-300 flex flex-col">
            <div className="flex gap-2 mb-4 overflow-x-auto overflow-y-hidden">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategoryId(cat.id)}
                  className={`px-4 py-2 rounded whitespace-nowrap ${activeCategoryId === cat.id
                    ? 'bg-teal-600 text-white'
                    : 'bg-gray-200'
                    }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
            {error && <div className="text-red-600 mb-4">{error}</div>}
            <div className="grid grid-cols-2 gap-2 overflow-y-auto mb-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="border rounded p-2 flex flex-col justify-between"
                >
                  <div>
                    <div className="font-bold">{item.title}</div>
                    <div className="text-sm text-gray-600">{item.description}</div>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <div className="font-semibold">{item.price.toLocaleString()} تومان</div>
                    <button
                      onClick={() => addItem(item)}
                      className="bg-teal-600 text-white px-2 py-1 rounded"
                    >
                      +
                    </button>
                  </div>
                </div>
              ))}
  
  
            </div>
            <div className='flex flex-row gap-2 mt-auto mb-0'>
              {/* پلی‌استیشن */}
              <div className="w-[50%] border rounded p-3 flex flex-col gap-3">
                <div className="font-bold">سفارش پلی‌استیشن</div>
  
                <div className="flex items-center gap-2">
                  <label>دسته:</label>
                  <select
                    value={psController}
                    onChange={(e) => setPsController(e.target.value)}
                    className="border rounded px-2 py-1"
                    disabled={psStarted}
                  >
                    <option value="2">۲ دسته</option>
                    <option value="4">۴ دسته</option>
                  </select>
                </div>
  
                <div className="flex items-center gap-2">
                  <label>دقیقه:</label>
                  <input type="number"
                    min="0" value={psMinutes} onChange={(e) => setPsMinutes(e.target.value)} className='border rounded px-2 py-1 text-center' disabled={!psStarted} />
                </div>
  
                <div className="flex gap-2">
                  <button
                    onClick={startPs}
                    disabled={psStarted}  // اگر شروع شده غیر فعال باشد
                    className={`flex-grow py-2 rounded ${psStarted ? 'bg-gray-400 cursor-not-allowed' : 'bg-[teal] text-white'}`}
                  >
                    شروع
                  </button>
                  <button
                    onClick={endPs}
                    disabled={!psStarted}  // اگر شروع نشده غیر فعال باشد
                    className={`flex-grow py-2 rounded ${!psStarted ? 'bg-gray-400 cursor-not-allowed' : 'bg-[teal] text-white'}`}
                  >
                    پایان
                  </button>
                </div>
              </div>
  
              {/* بردگیم */}
              <div className="w-[50%] border rounded p-3 flex flex-col gap-3">
                <div className="font-bold">سفارش بردگیم</div>
  
                <div className="flex items-center gap-2">
                  <label>تعداد نفرات:</label>
                  <input type="number"
                    min="0" value={bgPlayers} onChange={(e) => setBgPlayers(e.target.value)} className='border rounded px-2 py-1 text-center' disabled={bgStarted} />
                </div>
  
                <div className="flex items-center gap-2">
                  <label>دقیقه:</label>
                  <input type="number"
                    min="0" value={bgMinutes} onChange={(e) => setBgMinutes(e.target.value)} className='border rounded px-2 py-1 text-center' disabled={!bgStarted} />
                </div>
  
                <div className="flex gap-2">
                  <button
                    onClick={startBg}
                    disabled={bgStarted}
                    className={`flex-grow py-2 rounded ${bgStarted ? 'bg-gray-400 cursor-not-allowed' : 'bg-[teal] text-white'
                      }`}
                  >
                    شروع
                  </button>
                  <button
                    onClick={endBg}
                    disabled={!bgStarted}
                    className={`flex-grow py-2 rounded ${!bgStarted ? 'bg-gray-400 cursor-not-allowed' : 'bg-[teal] text-white'
                      }`}
                  >
                    پایان
                  </button>
                </div>
              </div>
            </div>
          </div>
  
          {/* سفارشات */}
          <div className="w-1/3 p-4 h-full bg-gray-100 flex flex-col justify-between">
            <h3 className="text-lg font-bold mb-2">سفارشات میز {table.name}</h3>
            <div className='h-full overflow-y-auto'>
  
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-right">نام</th>
                    <th>تعداد</th>
                    <th>قیمت</th>
                    <th>مجموع</th>
                    <th>عملیات</th>
                  </tr>
                </thead>
                <tbody>
                  {orderItems.map((item) => (
                    <tr key={item.id} className="border-b">
                      <td className="py-1 text-right">{item.title}</td>
                      <td className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => decreaseQty(item.id)}
                            className="px-1 bg-gray-300 rounded"
                          >
                            -
                          </button>
                          <span>{item.quantity}</span>
                          <button
                            onClick={() => increaseQty(item.id)}
                            className="px-1 bg-gray-300 rounded"
                          >
                            +
                          </button>
                        </div>
                      </td>
                      <td className="text-center">{item.price.toLocaleString()}</td>
                      <td className="text-center">
                        { /پلی‌استیشن |بردگیم/i.test(item.title) ? Math.floor((item.price * item.quantity) / 60).toLocaleString() : (item.price * item.quantity).toLocaleString()}
                      </td>
                      <td className="text-center">
                        <button
                          onClick={() => removeItem(item.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          حذف
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
  
  
            </div>
            <div className="mt-4 flex flex-col gap-2">
              <div className="pt-4 font-bold text-right">
                جمع کل:
                {' '}
                {orderItems.reduce((sum, it) => {
                  const isGame = /پلی‌استیشن |بردگیم/i.test(it.title);
                  const price = parseFloat(it.price); // اگر price از نوع number باشه، فقط بنویس: `it.price`
                  const itemTotal = it.quantity * price;
                  return sum + (isGame ? Math.floor(itemTotal / 60) : itemTotal);
                }, 0).toLocaleString()} تومان
              </div>
              <button
                onClick={saveAndClose}
                className="flex-grow bg-[teal] text-white px-4 py-2 rounded"
              >
                ذخیره و بستن
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  export default TableOrderPanel;