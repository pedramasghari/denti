// App.jsx
import React, { useState, useEffect } from 'react';
const { ipcRenderer } = window.require('electron');
import TableList from './tables'
import TableOrderPanel from './order'
import PrintView from './printview'
import AdminPanel from './adminpanel'
import { useRef } from 'react';



function TableSelectPanel({ table,onPrint ,onUpdate}) {
  const [orderItems, setOrderItems] = useState([]);
  const [offer,setOffer] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [phone, setPhone] = useState('');
  const [name, setname] = useState('');
  

  useEffect(() => {
    if (!table) return;
    if (table.user_name != '' || table.user_name != undefined) setname(table.user_name);
    if (table.user_phone != '' || table.user_phone != undefined) setPhone(table.user_phone);
    const fetchOrders = async () => {
      try {
        setLoading(true);
        setError(null);
        const orders = await ipcRenderer.invoke('get-orders-by-table', table.id);
        setOrderItems(
          orders.map((order) => ({
            id: order.id,
            title: order.product,
            price: order.price,
            quantity: order.quantity,
          }))
        );
      } catch (err) {
        setError('خطا در دریافت سفارش‌ها');
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [table]);
  const updateTable = async () => {
    await ipcRenderer.invoke('update-table', table);
    onUpdate();
  };

  if (!table) {
    return (
      <div className="flex-grow h-full flex flex-col items-center justify-center bg-[#333] text-gray-100" style={{borderRight:'2px solid #d4d4d4'}}>
        لطفاً یک میز را انتخاب کنید
      </div>
    );
  }

  // محاسبه مجموع کل
  const total = orderItems.reduce((sum, it) => {
                const isGame = (/پلی‌استیشن |بردگیم/i).test(it.title);
                const price = parseFloat(it.price); // اگر price از نوع number باشه، فقط بنویس: `it.price`
                const itemTotal = it.quantity * price;
                return sum + (isGame ? Math.floor(itemTotal / 60) : itemTotal);
              }, 0);
  
  return (
    <div className="flex-grow h-full flex flex-col" style={{borderRight:'2px solid #d4d4d4'}}>
      <div className="w-full bg-[#333] min-h-[5rem] flex flex-row justify-between items-center px-4 py-2" style={{borderBottom:'1px solid #d4d4d4'}}>
        <div className="text-white">{table.name}</div>
        <div className="flex flex-row gap-2">
          <input
            type="text"
            className="bg-[#333] text-white px-6 py-2 rounded-md"
            placeholder="نام و نام خانوادگی"
            value={name}
            onChange={(e) => {
              setname(e.target.value);
              table.user_name = e.target.value;
              table.name = table.user_name;
            }}
          />
          <input
            type="text"
            className="bg-[#333] text-white px-6 py-2 rounded-md"
            placeholder="شماره تماس"
            value={phone}
            onChange={(e) => {
              setPhone(e.target.value);
              table.user_phone = e.target.value;
            }}
          />
          <button
            className="bg-[teal] text-white px-4 py-2 rounded-md hover:bg-[#006666]"
            onClick={() => {
              updateTable();
            }}
          >
            ثبت
          </button>
        </div>
        <select
          value={offer}
          onChange={(e) => setOffer(e.target.value)}
          className="bg-[#333] text-white px-6 py-2 rounded-md"
        >
          <option value={0}>0%</option>
          <option value={10}>10%</option>
          <option value={15}>15%</option>
          <option value={20}>20%</option>
          <option value={25}>25%</option>
          <option value={30}>30%</option>
        </select>

      </div>

      <div className="w-full bg-[#333] flex-grow overflow-y-auto overflow-x-hidden p-4">
        <h3 className="text-white text-xl mb-4">لیست سفارشات</h3>

        {loading ? (
          <div className="text-white text-center">
            در حال بارگذاری سفارش‌ها...
          </div>
        ) : error ? (
          <div className="text-red-500 text-center">{error}</div>
        ) : orderItems.length === 0 ? (
          <div className="text-gray-300 text-center">هیچ سفارشی ثبت نشده</div>
        ) : (
          <table className="w-full text-white table-auto">
            <thead>
              <tr>
                <th className="border px-2 py-1">نام محصول</th>
                <th className="border px-2 py-1">تعداد</th>
                <th className="border px-2 py-1">قیمت واحد (تومان)</th>
                <th className="border px-2 py-1">مجموع (تومان)</th>
              </tr>
            </thead>
            <tbody>
              {orderItems.map((item) => (
                <tr key={item.id} className="text-center">
                  <td className="border px-2 py-1">{item.title}</td>
                  <td className="border px-2 py-1">{item.quantity}</td>
                  <td className="border px-2 py-1">
                    {item.price.toLocaleString()}
                  </td>
                  <td className="border px-2 py-1">
                    {/پلی‌استیشن |بردگیم/i.test(item.title)
                      ? Math.floor(
                          (item.price * item.quantity) / 60
                        ).toLocaleString()
                      : (item.price * item.quantity).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="w-full bg-[#333] min-h-[5rem] flex flex-row justify-between items-center px-4 py-2" style={{borderTop:'1px solid #d4d4d4'}}>
        <div className="text-white font-bold">
          مجموع سفارشات: {total.toLocaleString()} تومان
        </div>
        <div className="flex flex-row gap-2">
          <button
            className="bg-[teal] text-white px-4 py-2 rounded-md hover:bg-[#006666]"
            onClick={() => onPrint(table, true,offer)}
          >
            چاپ
          </button>
          <button
            className="bg-[teal] text-white px-4 py-2 rounded-md hover:bg-[#006666]"
            onClick={() => onPrint(table, false,offer)}
          >
            چاپ فاکتور
          </button>
        </div>
      </div>
    </div>
  );
}


export default function App() {
  const tableListRef = useRef();
  const [selectedTable, setSelectedTable] = useState(null);
  const [previewTable, setPreviewTable] = useState(null);
  const [printshow, setPrintshow] = useState(false);
  const [printTable, setPrintTable] = useState(null);
  const [previewPrint, setpreviewPrint] = useState(false);
  const [offerSelected,setOfferSelected] = useState(0);
  const [showAdmin, setShowAdmin] = useState(false);
  function handlePrint(table,priview,offer) {
    setPrintTable(table);
    setPrintshow(true);
    setpreviewPrint(priview);
    setOfferSelected(offer)
  }
  
   const handlePrintClose = () => {
    setPrintshow(false);
    setPrintTable(null);
    // 🟢 اینجا دوباره لیست میزها رو می‌گیریم
    tableListRef.current?.fetchTables?.();
    setPreviewTable(null);
    setSelectedTable(null);
  };
  useEffect(() => {
    if (printshow) {
      // وقتی وارد حالت چاپ شد، کمی صبر کن، بعد پرینت بزن و برگرد به رابط
      setTimeout(() => {
        window.electronAPI.print({ silent: true }); // یا هر تنظیمی که داری
        setPrintshow(false);
      }, 500); // صبر برای اینکه DOM کامل رندر بشه
    }
  }, [printshow]);

  // حالت چاپ فعال باشه؟ فقط فاکتور رو نشون بده
  
  if (showAdmin) {
  return <AdminPanel onClose={() => setShowAdmin(false)} />;
  }
  // حالت عادی برنامه
  return (

<div className="w-full h-screen bg-gray-800 flex flex-col" dir="rtl">
  {/* Header */}
  <div className="flex items-center justify-between p-4 ">
    <h1 className="text-xl font-bold text-gray-800">باشگاه بازی فکری شهباز</h1>
    <button
      onClick={() => setShowAdmin(true)}
      className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded transition-colors duration-200"
    >
      پنل ادمین
    </button>
  </div>

  {/* Main Content */}
  <div className="flex flex-1 overflow-hidden">
    {/* Sidebar: Table List */}
    <div className="w-96 bg-gray-800 text-white">
     
      <TableList
        ref={tableListRef}
        onDelete={(id) => {
          if (previewTable?.id === id) setPreviewTable(null);
          if (selectedTable?.id === id) setSelectedTable(null);
        }}
        onSelectTable={(table) => setPreviewTable(table)}
        onDoubleClickTable={(table) => {
          if (previewTable === table) setSelectedTable(table);
        }}
        className="py-2"
      />
    </div>

    {/* Middle Panel: Table Preview */}
    <div className="flex-1  overflow-y-auto">
      {previewTable ? (
        <TableSelectPanel
          table={previewTable}
          onPrint={(table, preview, offer) => handlePrint(table, preview, offer)}
          onUpdate={() => tableListRef.current?.fetchTables?.()}
        />
      ) : (
        <div className="flex items-center justify-center h-full text-gray-400">
          لطفاً یک میز را از لیست انتخاب کنید
        </div>
      )}
    </div>

    {/* Right Panel: Table Order */}
    {selectedTable && (
      <div className="w-96 bg-white shadow-lg p-6 overflow-y-auto border-l border-gray-200">
        <TableOrderPanel
          table={selectedTable}
          onClose={(table) => {
            setPreviewTable({ ...table });
            setSelectedTable(null);
          }}
        />
      </div>
    )}
  </div>

  {/* Print View Modal */}
  {printshow && printTable && (
    <PrintView
      offer={offerSelected}
      preview={previewPrint}
      table={printTable}
      onClose={handlePrintClose}
    />
  )}
</div>

    
  );
}

