import React, { useState, useEffect } from 'react';
import { saveSession, getSession, clearSession } from './adminSession';
import OrdersTab from './OrdersTab';
import IngredientsTab from './IngredientsTab';
import RecipesTab from './RecipesTab';

const { ipcRenderer } = window.require('electron');

export default function AdminPanel({ onClose }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [admin, setAdmin] = useState(null);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('orders'); // orders | ingredients | recipes

  useEffect(() => {
    const session = getSession();
    if (session) setAdmin(session.user);
  }, []);

  const handleLogin = async () => {
    setError('');
    const res = await ipcRenderer.invoke('admin-login', { username, password });
    if (!res.success) {
      setError(res.message);
      return;
    }
    saveSession(res);
    setAdmin(res.user);
  };

  const handleLogout = () => {
    clearSession();
    setAdmin(null);
  };

  // ⛔ فرم لاگین
  if (!admin) {
    return (
      <div className="w-full h-screen flex items-center justify-center bg-gray-100 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white bg-red-600 hover:bg-red-700 w-8 h-8 rounded-full flex items-center justify-center font-bold"
        >
          ×
        </button>

        <div className="bg-white p-6 rounded shadow w-80">
          <h2 className="text-xl font-bold mb-4 text-center">ورود ادمین</h2>
          <input
            className="w-full mb-2 p-2 border rounded"
            placeholder="نام کاربری"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            type="password"
            className="w-full mb-2 p-2 border rounded"
            placeholder="رمز عبور"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {error && <p className="text-red-600 text-sm mb-2">{error}</p>}
          <button
            onClick={handleLogin}
            className="w-full bg-red-600 text-white py-2 rounded"
          >
            ورود
          </button>
        </div>
      </div>
    );
  }

  // ✅ پنل ادمین با Tab
  return (
    <div className="w-full h-screen bg-gray-100 p-4 relative flex flex-col">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-white bg-red-600 hover:bg-red-700 w-8 h-8 rounded-full flex items-center justify-center font-bold"
      >
        ×
      </button>

      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl font-bold">پنل ادمین ({admin.username})</h1>
        <button
          onClick={handleLogout}
          className="bg-gray-800 text-white px-4 py-2 rounded"
        >
          خروج
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b mb-4">
        <button
          className={`px-4 py-2 ${activeTab === 'orders' ? 'border-b-2 border-blue-500 font-bold' : ''}`}
          onClick={() => setActiveTab('orders')}
        >
          سفارش‌ها
        </button>
        <button
          className={`px-4 py-2 ${activeTab === 'ingredients' ? 'border-b-2 border-blue-500 font-bold' : ''}`}
          onClick={() => setActiveTab('ingredients')}
        >
          مواد اولیه
        </button>
        <button
          className={`px-4 py-2 ${activeTab === 'recipes' ? 'border-b-2 border-blue-500 font-bold' : ''}`}
          onClick={() => setActiveTab('recipes')}
        >
          Recipe Cards
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto bg-white p-4 rounded shadow">
        {activeTab === 'orders' && <OrdersTab />}
        {activeTab === 'ingredients' && <IngredientsTab />}
        {activeTab === 'recipes' && <RecipesTab />}
      </div>
    </div>
  );
}
