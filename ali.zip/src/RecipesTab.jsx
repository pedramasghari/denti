import React, { useEffect, useState } from 'react'
import { SmartMultiSelect, NumberField } from './components/fields'

const { ipcRenderer } = window.require('electron')

export default function RecipesTab() {
  const [menuCategories, setMenuCategories] = useState([])
  const [activeCategory, setActiveCategory] = useState(null)
  const [menuItems, setMenuItems] = useState([])
  const [recipesMap, setRecipesMap] = useState({}) // menuItemId -> recipe|null
  const [materials, setMaterials] = useState([])
  const [activeRecipe, setActiveRecipe] = useState(null)
  const [loading, setLoading] = useState(false)

  /* ---------------- initial load ---------------- */
  useEffect(() => {
    loadInitialData()
  }, [])

  const loadInitialData = async () => {
    try {
      const cats = await ipcRenderer.invoke('get-menu-categories')
      setMenuCategories(cats)
      if (cats.length) setActiveCategory(cats[0].id)

      const mats = await ipcRenderer.invoke('get-materials')
      setMaterials(mats)
    } catch (err) {
      console.error('Error loading initial data', err)
      alert('خطا در بارگذاری داده‌ها')
    }
  }

  /* ---------------- load menu items + recipes ---------------- */
  useEffect(() => {
    if (activeCategory) loadCategoryData()
  }, [activeCategory])

  const loadCategoryData = async () => {
    setLoading(true)
    try {
      // دریافت ایتم های منو
      const items = await ipcRenderer.invoke(
        'get-menu-items-by-category',
        activeCategory
      )
      setMenuItems(items)

      // دریافت رسپی کارت ها
      const ids = items.map(i => i.id)
      if (ids.length) {
        const recipes = await ipcRenderer.invoke(
          'get-recipe-cards-by-menu-items',
          ids
        )

        const map = {}
        recipes.forEach(r => {
          map[r.menu_item_id] = r || null
        })
        setRecipesMap(map)
      } else {
        setRecipesMap({})
      }
    } catch (err) {
      console.error('Error loading category data', err)
      alert('خطا در بارگذاری ایتم‌ها یا رسپی‌ها')
    } finally {
      setLoading(false)
    }
  }

  /* ---------------- helpers ---------------- */
  const materialOptions = materials.map(m => ({
    label: `${m.name} (${m.unit})`,
    value: m.id,
    data: m,
  }))

  const calcCost = (recipe) => {
    if (!recipe || !recipe.ingredients) return 0
    return recipe.ingredients.reduce((sum, ing) => {
      const price = Number(ing.unitPrice || 0)
      const amount = Number(ing.amount || ing.quantity || 0)
      return sum + price * amount
    }, 0)
  }

  const profitPercent = (price, cost) => {
    if (!cost) return 0
    return (((price - cost) / cost) * 100).toFixed(1)
  }

  /* ---------------- recipe editor ---------------- */
  const openRecipeEditor = (menuItem) => {
    const recipe = recipesMap[menuItem.id]
    const safeIngredients = recipe?.ingredients?.map(i => ({
      value: i.materialId ?? i.id,
      label: i.name ?? '',
      amount: i.amount ?? i.quantity ?? 0,
      unit: i.unit ?? '',
      unitPrice: i.unitPrice ?? 0,
    })) || []

    setActiveRecipe({
      id: recipe?.id || null,
      menuItem,
      price: menuItem.price,
      ingredients: safeIngredients,
    })
  }

  const saveRecipe = async () => {
    if (!activeRecipe) return
    const payload = {
      id: activeRecipe.id,
      menuItemId: activeRecipe.menuItem.id,
      ingredients: activeRecipe.ingredients.map(i => ({
        material_id: i.value,
        quantity: i.amount,
      })),
    }

    try {
      if (activeRecipe.id) {
        await ipcRenderer.invoke('update-recipe', payload)
      } else {
        const res = await ipcRenderer.invoke('create-recipe', payload)
        payload.id = res.id
      }
      setActiveRecipe(null)
      loadCategoryData()
    } catch (err) {
      console.error('خطا هنگام ذخیره رسپی:', err)
      alert('خطا هنگام ذخیره رسپی! لطفاً دوباره تلاش کنید.')
    }
  }

  const deleteRecipe = async () => {
    if (!activeRecipe?.id) return
    if (!confirm('رسپی حذف شود؟')) return
    try {
      await ipcRenderer.invoke('delete-recipe', activeRecipe.id)
      setActiveRecipe(null)
      loadCategoryData()
    } catch (err) {
      console.error('خطا هنگام حذف رسپی:', err)
      alert('خطا هنگام حذف رسپی! لطفاً دوباره تلاش کنید.')
    }
  }

  /* ---------------- UI ---------------- */
  return (
    <div className="p-4">
      <h3 className="font-bold mb-4">Recipe Cards</h3>

      {/* categories */}
      <div className="flex gap-2 mb-4 flex-wrap">
        {menuCategories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1 rounded ${
              activeCategory === cat.id
                ? 'bg-blue-500 text-white'
                : 'bg-gray-200'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* cards */}
      {loading ? (
        <div>در حال بارگذاری...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {menuItems.map(item => {
            const recipe = recipesMap[item.id]
            const cost = recipe ? calcCost(recipe) : 0

            return (
              <div
                key={item.id}
                onDoubleClick={() => openRecipeEditor(item)}
                className="border rounded-xl p-4 shadow cursor-pointer hover:shadow-lg"
              >
                <h4 className="font-bold">{item.title}</h4>
                <p className="text-sm text-gray-500">{item.description}</p>

                

                {recipe ? (
                  <>
                    <div className="my-2 text-xs border-t border-b pt-2">
                      {recipe.ingredients.map((ing, idx) => {
                        const name = ing.name || 'بدون نام'
                        const amount = ing.quantity || 0
                        const unit = ing.unit || ''
                        const price = ing.unitPrice || 0
                        return (
                          <div key={idx} className="flex justify-between">
                            <span>{name} ({amount} {unit})</span>
                            <span>{(price * amount).toLocaleString()}</span>
                          </div>
                        )
                      })}
                    </div>
                    <div className="mt-2 text-sm">
                  قیمت فروش: {item.price.toLocaleString()}
                </div>
                    <div className="text-sm mt-1">
                      هزینه کل: {cost.toLocaleString()}
                    </div>
                    <div className="text-sm text-green-600">
                      سود: {profitPercent(item.price, cost)}%
                    </div>
                  </>
                ) : (
                  <div className="text-xs text-red-500 mt-2">
                    بدون رسپی
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* recipe editor modal */}
      {activeRecipe && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
          <div className="bg-white w-full max-w-xl rounded-xl p-4">
            <h4 className="font-bold mb-2">
              رسپی: {activeRecipe.menuItem.title}
            </h4>

            <SmartMultiSelect
              label="مواد اولیه"
              value={activeRecipe.ingredients}
              options={materialOptions}
              onChange={(vals) =>
                setActiveRecipe(r => ({
                  ...r,
                  ingredients: vals.map(v => {
                    const prev = r.ingredients.find(i => i.value === v.value) || {}
                    return {
                      ...v,
                      amount: prev.amount || 1,
                      unit: prev.unit || '',
                      unitPrice: prev.unitPrice || 0,
                    }
                  }),
                }))
              }
            />

            <div className="grid grid-cols-2 gap-2 mt-2">
              {activeRecipe.ingredients.map((ing, idx) => (
                <NumberField
                  key={ing.value}
                  label={`${ing.label} (${ing.unit})`}
                  value={ing.amount}
                  onChange={(val) => {
                    const arr = [...activeRecipe.ingredients]
                    arr[idx].amount = val
                    setActiveRecipe(r => ({ ...r, ingredients: arr }))
                  }}
                />
              ))}
            </div>

            <div className="mt-3 text-sm">
              <div>
                هزینه کل:{' '}
                {calcCost(activeRecipe).toLocaleString()}
              </div>
              <div>قیمت فروش: {activeRecipe.price.toLocaleString()}</div>
              <div>
                سود: {profitPercent(activeRecipe.price, calcCost(activeRecipe))}%
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-4">
              {activeRecipe.id && (
                <button
                  onClick={deleteRecipe}
                  className="bg-red-500 text-white px-3 py-1 rounded"
                >
                  حذف
                </button>
              )}
              <button
                onClick={() => setActiveRecipe(null)}
                className="bg-gray-400 text-white px-3 py-1 rounded"
              >
                لغو
              </button>
              <button
                onClick={saveRecipe}
                className="bg-green-500 text-white px-3 py-1 rounded"
              >
                ذخیره
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
