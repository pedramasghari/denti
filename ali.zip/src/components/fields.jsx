import React from 'react'
import Select from 'react-select'

/* ------------ input helpers ------------ */

export const ReadOnlyRow = ({ label, value }) => (
  <div className="flex flex-col text-xs md:text-sm bg-gray-50 rounded-md p-2">
    <span className="text-gray-500 mb-0.5">{label}</span>
    <span>{value}</span>
  </div>
)

export const TextField = ({ label, value, onChange, type = 'text' }) => (
  <div className="flex flex-col text-xs md:text-sm">
    <label className="mb-1 text-gray-600">{label}</label>
    <input
      className="border rounded-md px-2 py-1"
      value={value ?? ''}
      type={type}
      onChange={(e) => onChange(e.target.value)}
    />
  </div>
)

export const NumberField = ({ label, value, onChange }) => (
  <div className="flex flex-col text-xs md:text-sm">
    <label className="mb-1 text-gray-600">{label}</label>
    <input
      className="border rounded-md px-2 py-1"
      value={value ?? ''}
      type="number"
      onChange={(e) => onChange(Number(e.target.value))}
    />
  </div>
)

export const TextAreaField = ({ label, value, onChange }) => (
  <div className="flex flex-col text-xs md:text-sm">
    <label className="mb-1 text-gray-600">{label}</label>
    <textarea
      className="border rounded-md px-2 py-1 min-h-[60px]"
      value={value ?? ''}
      onChange={(e) => onChange(e.target.value)}
    />
  </div>
)

export const SelectField = ({ label, value, onChange, options }) => (
  <div className="flex flex-col text-xs md:text-sm">
    <label className="mb-1 text-gray-600">{label}</label>
    <select
      className="border rounded-md px-2 py-1"
      value={value ?? ''}
      onChange={(e) => onChange(e.target.value || null)}
    >
      <option value="">انتخاب کنید...</option>
      {options.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
  </div>
)

/* ------------ Smart Selects ------------ */


import CreatableSelect from 'react-select/creatable';

export const SmartMultiSelect = ({
  label,
  value,
  options,
  onChange,
  placeholder = 'جستجو و انتخاب...',
}) => {
  return (
    <div className="flex flex-col gap-1 w-full text-sm">
      {label && <label className="font-medium text-gray-700 mb-1">{label}</label>}
      <CreatableSelect
        isMulti
        options={options}
        value={value}
        onChange={(selected) => {
          // selected می‌تونه null باشه
          if (!selected) return onChange([]);
          // map کردن مقادیر و گرفتن label/value
          const formatted = selected.map(item => item.__isNew__ ? { label: item.label, value: item.label } : item);
          onChange(formatted);
        }}
        placeholder={placeholder}
        className="text-right"
        formatCreateLabel={(inputValue) => `اضافه کردن: "${inputValue}"`}
      />
    </div>
  );
};


export const SmartSingleSelect = ({
  label,
  value,
  options,
  onChange,
  placeholder = 'انتخاب کنید...',
}) => {
  return (
    <div className="flex flex-col gap-1 w-full text-sm">
      {label && <label className="font-medium text-gray-700 mb-1">{label}</label>}
      <Select
        isMulti={false}
        options={options}
        value={value}
        onChange={(selected) => onChange(selected || null)}
        placeholder={placeholder}
        className="text-right"
      />
    </div>
  )
}
