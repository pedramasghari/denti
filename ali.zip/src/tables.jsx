import React, { useEffect, useState,   forwardRef, useImperativeHandle   } from 'react';
const { ipcRenderer } = window.require('electron');
const TableList = forwardRef(({ onSelectTable, onDoubleClickTable ,onDelete}, ref) => {
  const [tables, setTables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchTables();
  }, []);

  const fetchTables = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await ipcRenderer.invoke('get-tables');
      setTables(data);
    } catch (err) {
      console.error('خطا در دریافت میزها:', err);
      setError('خطا در دریافت اطلاعات میزها');
    } finally {
      setLoading(false);
    }
  };

  const addTable = async () => {
    try {
      setError(null);
      await ipcRenderer.invoke('create-table', {
        name: `میز ${tables.length + 1}`,
        user_name: '',
        user_phone: '',
      });
      fetchTables();
    } catch (error) {
      console.error('خطا در ایجاد میز:', error);
      setError('خطا در ایجاد میز جدید');
    }
  };

  const deleteTable = async (id) => {
    try {
      setError(null);
      await ipcRenderer.invoke('delete-table', id);
      fetchTables();
      
    } catch (error) {
      console.error('خطا در حذف میز:', error);
      setError('خطا در حذف میز');
    }finally{
      onDelete(id);
    }
    
  };

  useImperativeHandle(ref, () => ({
    fetchTables,
  }));

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 h-full flex flex-col" dir="rtl">
      <div className="mb-8">
        <div className="w-full flex">
          <button
            onClick={addTable}
            className="bg-[teal] mx-auto text-white px-6 py-2 rounded-lg text-lg mb-6"
          >
            ایجاد میز جدید
          </button>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}
      </div>

      <hr className="border-gray-600 mb-4" />
      <h2 className="text-2xl font-bold text-white mb-4">میزها</h2>

      {tables.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-300 text-xl">هیچ میزی موجود نیست</p>
        </div>
      ) : (
        <div className="flex-grow overflow-y-auto overflow-x-hidden">
          <ul className="rounded-lg">
            {tables.map((table) => (
              <li
                key={table.id}
                onClick={() => onSelectTable(table)}
                onDoubleClick={() => onDoubleClickTable(table)}
                className="flex flex-row justify-between px-4 py-2 hover:bg-[#444] rounded-lg mb-2 cursor-pointer"
              >
                <span className="text-xl text-white my-auto">{table.name}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteTable(table.id);
                  }}
                  className="text-red-500 hover:text-red-700 px-4 py-2 rounded-lg text-xl"
                >
                  ×
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
})
export default TableList;