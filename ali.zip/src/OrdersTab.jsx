import React, { useState, useEffect } from "react";
import { DatePicker } from "react-advance-jalaali-datepicker";
import jalaali from "jalaali-js";
import { SmartMultiSelect } from "./components/fields";
import DataTable from 'react-data-table-component';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
const { ipcRenderer } = window.require("electron");

export default function OrdersTab() {
  const today = new Date();
  const { jy, jm, jd } = jalaali.toJalaali(today);

  const [startDateSh, setStartDateSh] = useState(`${jy}/${String(jm).padStart(2, '0')}/01`);
  const [endDateSh, setEndDateSh] = useState(`${jy}/${String(jm).padStart(2, '0')}/${String(jd).padStart(2, '0')}`);
  const [ordersSummary, setOrdersSummary] = useState([]);
  const [factors, setFactors] = useState([]);
  const [totalSales, setTotalSales] = useState(0);
  const [totalFactor, setTotalFactor] = useState(0);
  const [allMenuItems, setAllMenuItems] = useState([]);
  const [viewers, setViewers] = useState([]);
  const [newViewerName, setNewViewerName] = useState('');
  const [selectedItems, setSelectedItems] = useState([]);
  const [editingViewers, setEditingViewers] = useState({});

  const normalizeItemName = (name) => {
    const lower = name.toLowerCase();
    if (lower.includes("پلی‌استیشن") || lower.includes('playstation')) return 'پلی‌استیشن';
    if (lower.includes('بردگیم') || lower.includes('board')) return 'بردگیم';
    if (lower.includes('مافیا')) return 'مافیا';
    if (lower.includes('d&d')) return 'd&d';
    return name;
  };

  const shamsiToGregorian = (shamsiStr, endOfDay = false) => {
    const [jy, jm, jd] = shamsiStr.split("/").map(Number);
    const { gy, gm, gd } = jalaali.toGregorian(jy, jm, jd);
    return new Date(gy, gm - 1, gd, endOfDay ? 23 : 0, endOfDay ? 59 : 0, endOfDay ? 59 : 0, endOfDay ? 999 : 1).toISOString();
  };

  const fetchOrdersSummary = async () => {
    try {
      const res = await ipcRenderer.invoke("get-orders-summary", {
        startDate: shamsiToGregorian(startDateSh),
        endDate: shamsiToGregorian(endDateSh, true),
      });

      if (!res.success) return alert(res.error);

      setOrdersSummary(res.summary || []);
      setFactors(res.factors || []);

      const itemsMap = new Map();
      res.summary.forEach(obj => {
        const name = normalizeItemName(obj.item);
        if (itemsMap.has(name)) {
          const existing = itemsMap.get(name);
          itemsMap.set(name, { name, quantity: existing.quantity + obj.quantity, total: existing.total + obj.total });
        } else {
          itemsMap.set(name, { name, quantity: obj.quantity, total: obj.total });
        }
      });
      setAllMenuItems(Array.from(itemsMap.values()));

      setTotalFactor(res.factors.reduce((s, f) => s + Number(f.total || 0), 0));
      setTotalSales(res.totalAmount);
    } catch (err) {
      console.error(err);
      alert('خطا در ارتباط با سرور');
    }
  };

  const fetchViewers = async () => {
    try {
      const savedViewers = await ipcRenderer.invoke("get-order-viewers");
      setViewers(savedViewers.viewers || []);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchOrdersSummary();
    fetchViewers();
  }, []);

  const handleSaveViewer = async () => {
    if (!newViewerName || selectedItems.length === 0) return alert("لطفاً نام و آیتم‌ها را انتخاب کنید");

    try {
      await ipcRenderer.invoke("create-order-viewer", {
        name: newViewerName,
        items: selectedItems.map(i => i.label || i.value || i),
      });
      setNewViewerName("");
      setSelectedItems([]);
      fetchViewers();
      alert("Viewer ذخیره شد");
    } catch (err) {
      console.error(err);
      alert("خطا در ذخیره Viewer");
    }
  };

  const columns = [
    { name: 'تاریخ و ساعت', selector: row => row.created_at, sortable: true },
    { name: 'نام میز', selector: row => row.name, sortable: true },
    { name: 'مجموع', selector: row => Number(row.total), sortable: true, right: true, format: row => Number(row.total).toLocaleString() },
  ];

  const BASE_COLORS = [
  '#3b82f6',
  '#22c55e',
  '#f97316',
  '#a855f7',
  '#ef4444',
  '#14b8a6',
];

const getColor = (index) => {
  if (index < BASE_COLORS.length) return BASE_COLORS[index];
  const hue = (index * 47) % 360;
  return `hsl(${hue}, 65%, 55%)`;
};


  return (
    <div className="p-4 space-y-6">
      <h3 className="font-bold text-xl">مدیریت سفارشات با Viewer و تاریخ شمسی</h3>

      {/* بازه زمانی */}
      <div className="flex gap-4 flex-wrap items-end">
        <div>
          <label className="block text-sm font-medium mb-1">تاریخ شروع</label>
          <DatePicker
            placeholder="انتخاب تاریخ شروع"
            format="jYYYY/jMM/jDD"
            preSelected={startDateSh}
            onChange={(unix, formatted) => setStartDateSh(formatted)}
            isGregorian={false}
            maxDate={`${jy}/${String(jm).padStart(2,'0')}/${String(jd).padStart(2,'0')}`}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">تاریخ پایان</label>
          <DatePicker
            placeholder="انتخاب تاریخ پایان"
            format="jYYYY/jMM/jDD"
            preSelected={endDateSh}
            onChange={(unix, formatted) => setEndDateSh(formatted)}
            isGregorian={false}
            maxDate={`${jy}/${String(jm).padStart(2,'0')}/${String(jd).padStart(2,'0')}`}
          />
        </div>
        <button onClick={fetchOrdersSummary} className="bg-blue-500 text-white px-4 py-2 rounded">
          نمایش خلاصه
        </button>
      </div>

      {/* ساخت Viewer */}
      <div className="border p-4 rounded shadow space-y-2">
        <h4 className="font-bold mb-2">ساخت Viewer جدید</h4>
        <div className="flex gap-2 flex-wrap items-end">
          <input
            type="text"
            className="border p-2 rounded flex-1"
            placeholder="نام Viewer"
            value={newViewerName}
            onChange={e => setNewViewerName(e.target.value)}
          />
          <div className="flex-1">
            <SmartMultiSelect
              options={allMenuItems.map(i => ({ label: i.name, value: i.name }))}
              isMulti
              allowCustom
              value={selectedItems}
              onChange={setSelectedItems}
            />
          </div>
          <button onClick={handleSaveViewer} className="bg-green-500 text-white px-4 py-2 rounded">ذخیره</button>
        </div>
      </div>

      {/* مجموع فروش و فاکتور */}
      <div className="flex gap-6 text-lg font-bold">
        <div>مجموع فروش: {totalSales.toLocaleString()} تومان</div>
        <div>مجموع فاکتور: {totalFactor.toLocaleString()} تومان</div>
      </div>

      {/* Viewerها + جدول فاکتورها */}
      <div className="flex gap-6 flex-wrap">
        <div className="flex-1 grid grid-cols-2 gap-4">
          {viewers.map((viewer) => {
  const editing = editingViewers[viewer.id] || {
    isEditing: false,
    name: viewer.name,
    items: [...viewer.items],
  };

  const itemsToUse = editing.isEditing ? editing.items : viewer.items;

  // محاسبه سهم آیتم‌های Viewer از کل فروش
  const viewerItemTotals = {};
  ordersSummary.forEach(o => {
    const normalized = normalizeItemName(o.item);
    if (itemsToUse.includes(normalized)) {
      viewerItemTotals[normalized] =
        (viewerItemTotals[normalized] || 0) + o.total;
    }
  });

  const viewerSum = Object.values(viewerItemTotals)
    .reduce((s, v) => s + v, 0);

  const othersTotal = totalSales - viewerSum;

  const chartData = [
    ...Object.entries(viewerItemTotals).map(([name, value]) => ({
      name,
      value
    })),
    { name: 'سایر', value: othersTotal }
  ].filter(d => d.value > 0);

  const percentOfTotal = totalSales
    ? ((viewerSum / totalSales) * 100).toFixed(1)
    : 0;

  return (
    <div
      key={viewer.id}
      className="bg-white border rounded-xl p-4 shadow hover:shadow-lg transition"
      onDoubleClick={() =>
        setEditingViewers(prev => ({
          ...prev,
          [viewer.id]: { ...editing, isEditing: true }
        }))
      }
    >
      {editing.isEditing ? (
        /* حالت ویرایش */
        <div className="flex flex-col gap-2">
          <input
            className="border p-2 rounded"
            value={editing.name}
            onChange={e =>
              setEditingViewers(prev => ({
                ...prev,
                [viewer.id]: { ...editing, name: e.target.value }
              }))
            }
          />

          <SmartMultiSelect
            options={allMenuItems.map(i => ({
              label: i.name,
              value: i.name
            }))}
            value={editing.items.map(i => ({ label: i, value: i }))}
            onChange={selected =>
              setEditingViewers(prev => ({
                ...prev,
                [viewer.id]: {
                  ...editing,
                  items: selected.map(s => s.value)
                }
              }))
            }
          />

          <div className="flex gap-2">
            <button
              className="bg-green-500 text-white px-3 py-2 rounded"
              onClick={async () => {
                await ipcRenderer.invoke('update-order-viewer', {
                  id: viewer.id,
                  name: editing.name,
                  items: editing.items
                });
                setEditingViewers(prev => ({
                  ...prev,
                  [viewer.id]: { ...editing, isEditing: false }
                }));
                fetchViewers();
              }}
            >
              ذخیره
            </button>

            <button
              className="bg-red-500 text-white px-3 py-2 rounded"
              onClick={async () => {
                await ipcRenderer.invoke('delete-order-viewer', viewer.id);
                fetchViewers();
              }}
            >
              حذف
            </button>
          </div>
        </div>
      ) : (
        <>
          <h4 className="font-bold text-lg mb-2 text-center">
            {viewer.name}
          </h4>

          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={230}>
              <PieChart>
                <Pie
                  data={chartData}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={45}
                  outerRadius={85}
                  label={({ name, percent }) =>
                    `${name} ${(percent * 100).toFixed(1)}%`
                  }
                >
                  {chartData.map((_, i) => (
                    <Cell key={i} fill={getColor(i)} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={v =>
                    `${Number(v).toLocaleString()} تومان`
                  }
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="text-center text-gray-400 text-sm">
              داده‌ای وجود ندارد
            </div>
          )}

          <div className="mt-2 text-center">
            <div className="font-bold">
              {viewerSum.toLocaleString()} تومان
            </div>
            <div className="text-sm text-gray-600">
              {percentOfTotal}% از کل فروش
            </div>
          </div>
        </>
      )}
    </div>
  );
})}


        </div>

        <div className="flex-1">
          <DataTable
            columns={columns}
            data={factors}
            pagination
            highlightOnHover
            striped
            defaultSortField="created_at"
            persistTableHead
            noHeader
          />
        </div>
      </div>
    </div>
  );
}
