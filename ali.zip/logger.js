const { BrowserWindow } = require('electron');

function sendToRenderer(level, payload) {
  const win = BrowserWindow.getAllWindows()[0];
  if (win && win.webContents) {
    win.webContents.send('backend-log', {
      level,
      payload,
      time: new Date().toISOString(),
    });
  }
}

function logObj(tag, obj) {
  const data = {
    tag,
    data: obj,
  };

  console.log(`[BACKEND:${tag}]`, obj); // ترمینال

  sendToRenderer('info', data);
}

function logInfo(message) {
  console.log('[BACKEND]', message);
  sendToRenderer('info', message);
}

function logError(tag, err) {
  console.error(`[BACKEND:${tag}]`, err);
  sendToRenderer('error', {
    tag,
    error: err?.stack || err,
  });
}

module.exports = {
  logObj,
  logInfo,
  logError,
};
